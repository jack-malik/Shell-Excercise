import pyodbc
import sqlalchemy
import configparser
import sys
import logging
import os

config = configparser.ConfigParser()
STASCO_HOME = os.getenv('STASCO_HOME', '.')
STASCO_CFG_HOME = os.path.join(STASCO_HOME, 'cfg')
config.read(os.path.join(STASCO_CFG_HOME, 'credentials.ini'))

logger_ = logging.getLogger(__name__)
logger_.setLevel(logging.DEBUG)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('[%(asctime)s]-[%(name)s]-[%(levelname)s]: %(message)s')
handler.setFormatter(formatter)
logger_.addHandler(handler)

def dw_connect():
    """
    This function instantiates a pyodbc connection to the Data Platform project, DEV Data Warehouse.

    Returns: pyodbc.connection

    """
    user = config['DATA WAREHOUSE DEV']['user']
    password = config['DATA WAREHOUSE DEV']['password']
    driver = 'ODBC Driver 13 for SQL Server'
    server = 'seedataplatform-dev.database.windows.net'
    database = 'SEEDATAPLATFORM_DEV'
    conn = pyodbc.connect(
        'DRIVER={' + driver + '};SERVER=' + server + ';DATABASE=' + database + ';UID=' + user + ';PWD=' + password,
        autocommit = True)
    return conn


def dw_prod_connect():
    """
    This function instantiates a pyodbc connection to the Data Platform project, PROD Data Warehouse.

    Returns: pyodbc.connection

    """
    user = config['DATA WAREHOUSE PROD']['user']
    password = config['DATA WAREHOUSE PROD']['password']
    driver = 'ODBC Driver 13 for SQL Server'
    server = 'seedataplatform-prod.database.windows.net'
    database = 'SEEDATAPLATFORM'
    conn = pyodbc.connect(
        'DRIVER={' + driver + '};SERVER=' + server + ';DATABASE=' + database + ';UID=' + user + ';PWD=' + password,
        autocommit=True)
    return conn


def pyodbc_connect(connection_name=None):
    """
    This function instantiates a pyodbc connection to the GAS_FUNDAMENTALS database.
    Returns: pyodbc.connection

    """
#    user = config['GAS FUNDAMENTALS']['user']
#    password = config['GAS FUNDAMENTALS']['password']
    if not connection_name:
        connection_name = 'GAS FUNDAMENTALS'

    if not config.has_section(connection_name):
        msg = "No configuration information found for connection name: '{}'.".format(connection_name)
        raise RuntimeError(msg)

    # check for user and password
    if not config.has_option(connection_name, 'user'):
        msg = "No user information found for connection: '{}'.".format(connection_name)
        raise RuntimeError(msg)

    if not config.has_option(connection_name, 'password'):
        msg = "No password information found for connection with name: '{}'.".format(connection_name)
        raise RuntimeError(msg)

    server_name = "seedataplatform-dev.database.windows.net"
    if config.has_option(connection_name, 'server_name'):
        server_name = config.get(connection_name, 'server_name')

    db_name = 'GAS_FUNDAMENTALS'
    if config.has_option(connection_name, 'db_name'):
        db_name = config.get(connection_name, 'db_name')

    user = config.get(connection_name, 'user')
    password = config.get(connection_name, 'password')

    # driver = 'ODBC Driver 13 for SQL Server'
    driver = 'SQL Server Native Client 11.0'
    connect_str = 'DRIVER={' + driver + '};SERVER=' + server_name + ';DATABASE=' + db_name + \
                  ';UID=' + user + ';PWD={' + password + '}'
    conn = pyodbc.connect(connect_str, autocommit=True)
    return conn


def gf_connect(connection_name=None):
    """
    This function instantiates a pyodbc connection to the GAS_FUNDAMENTALS database.

    Returns: pyodbc.connection

    """
    if not connection_name:
        connection_name = 'GAS FUNDAMENTALS'
    user = config[connection_name]['user']
    password = config[connection_name]['password']
    # driver = 'ODBC Driver 13 for SQL Server'
    driver = 'SQL Server Native Client 11.0'
    server = 'seedataplatform-dev.database.windows.net'
    if config.has_option(connection_name, 'server_name'):
        server = config.get(connection_name, 'server_name')

    database = 'GAS_FUNDAMENTALS'
    if config.has_option(connection_name, 'db_name'):
        database = config.get(connection_name, 'db_name')

    conn_str = 'DRIVER={' + driver + '};SERVER=' + server + ';DATABASE=' + database + \
               ';UID=' + user + ';PWD={' + password + '}'
    conn = pyodbc.connect(conn_str, autocommit=True)
    return conn


def wth_connect_personal():
    """
    This function instantiates a pyodbc connection to the GAS_FUNDAMENTALS database using an individuals credentials.

    Returns: pyodbc.connection

    """
    user = config['GAS FUNDAMENTALS PERSONAL']['user']
    password = config['GAS FUNDAMENTALS PERSONAL']['password']
    driver = 'ODBC Driver 13 for SQL Server'
    server = 'seedataplatform-dev.database.windows.net'
    database = 'Systematic Trading'
    conn = pyodbc.connect(
        'DRIVER={' + driver + '};SERVER=' + server + ';DATABASE=' + database + ';UID=' + user + ';PWD={' + password + '}',
        autocommit=True)
    return conn


def gf_connect_sqlalchemy():
    """
    This function instantiates a SQLAlchemy engine to the GAS_FUNDAMENTALS database.

    Only required when writing back to the database using pandas.

    Returns: sqlalchemy.engine

    """
    user = config['GAS FUNDAMENTALS']['user']
    password = config['GAS FUNDAMENTALS']['password']
    driver = 'ODBC Driver 13 for SQL Server'
    server = 'seedataplatform-dev.database.windows.net'
    database = 'GAS_FUNDAMENTALS'
    conn = sqlalchemy.create_engine(
        "mssql+pyodbc://" + user + ":" + password + "@" + server + "/" + database + '?driver=ODBC+Driver+13+for+SQL+Server',
        echo=False,
        connect_args={'driver': driver}
    )
    return conn


def wth_connect():
    """
    This function instantiates a pyodbc connection to the [Systematic Trading] database.

    Returns: pyodbc.connection

    """
    user = config['SYSTEMATIC TRADING']['user']
    password = config['SYSTEMATIC TRADING']['password']
    # driver = 'ODBC Driver 13 for SQL Server'
    driver = 'SQL Server Native Client 11.0'
    server = 'seedataplatform-dev.database.windows.net'
    database = 'Systematic Trading'
    conn = pyodbc.connect(
        'DRIVER={' + driver + '};SERVER=' + server + ';DATABASE=' + database + ';UID=' + user + ';PWD=' + password,
        autocommit=True)
    return conn


def lilac_connect_gas_vm():
    """
    This function instantiates a pyodbc connection to the LILAC database.

    Returns: pyodbc.connection

    """
    user = config['LILAC GAS VM']['user']
    password = config['LILAC GAS VM']['password']
    # driver = 'ODBC Driver 13 for SQL Server'
    driver = 'SQL Server Native Client 11.0'
    server = 'shellfdmprod.lilacenergy.com'
    database = 'FDMData'
    conn = pyodbc.connect(
        'DRIVER={' + driver + '};SERVER=' + server + ';DATABASE=' + database + ';UID=' + user + ';PWD=' + password,
        autocommit=True)
    return conn


def azure_systrading_connection_string_for_bcp():
    """
    This function returns database connection details for the [Systematic Trading] database for use
    with the BCP programme.

    Returns: dict

    """
    global config
    user = config['SYSTEMATIC TRADING']['user']
    password = config['SYSTEMATIC TRADING']['password']
    return dict(db_server="seedataplatform-dev.database.windows.net,1433",
                db_user=user,
                db_pwd=password)


def azure_gfun_connection_string_for_bcp(connection_name=None):
    """
    This function returns database connection details for the GAS_FUNDAMENTALS database for use
    with the BCP programme.

    Returns: dict

    """
    db_server = "seedataplatform-dev.database.windows.net,1433"
    if connection_name:
        if config.has_option(connection_name, 'server_name'):
            db_server = config[connection_name]['server_name']

    if not connection_name:
        connection_name = 'GAS FUNDAMENTALS'
    db_name = config[connection_name]['db_name']
    user = config[connection_name]['user']
    password = config[connection_name]['password']
    return dict(db_server=db_server, db_user=user, db_pwd=password, db_name=db_name)


def azure_dw_connection_string_for_bcp():
    """
    This function returns database connection details for the Data Platform project, DEV Data Warehouse
    for use with the BCP programme.

    Returns: dict

    """
    user = config['DATA WAREHOUSE DEV']['user']
    password = config['DATA WAREHOUSE DEV']['password']
    return dict(db_server="seedataplatform-dev.database.windows.net,1433",
                db_user=user,
                db_pwd=password)
