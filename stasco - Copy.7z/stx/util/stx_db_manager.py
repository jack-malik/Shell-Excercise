import os
import sys
import logging
import datetime as dt

logger_ = logging.getLogger(__name__)
logger_.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('[%(asctime)s]-[%(name)s]-[%(levelname)s]: %(message)s')
handler.setFormatter(formatter)
logger_.addHandler(handler)

DEFAULT_DATA_START_DATE_STR = '2010-10-01'

class StxDbManager(object):

    DEFAULT_DATA_START_DATE = dt.datetime.strptime(DEFAULT_DATA_START_DATE_STR, '%Y-%m-%d')

    DEFAULT_SCHEMA_NAME = 'LDZ'

    CAL_DATE_KEY = 'DATE_KEY'
    CAL_CALENDAR_DATE = 'CALENDAR_DATE'
    CAL_CALENDAR_DATE_STR = 'CALENDAR_DATE_STR'

    STX_CALENDAR_TBL_NAME = "STX_CALENDAR"
    STX_LOCAT_TEMPTE_TBL_NAME = "STX_LOCATION_TEMPERATURE"
    STX_MODEL_PARAMETER_TBL_NAME = "STX_MODEL_PARAMETER"
    STX_GAS_DEMAND_TBL_NAME = "STX_GAS_DEMAND"
    STX_LOCAT_WEIGHT_FACTOR_TBL_NAME = "STX_LOCATION_WEIGHT_FACTOR"
    STX_WEATHER_STATION_TBL_NAME = "STX_WEATHER_STATION"
    STX_MODEL_INPUT_CALC_TBL_NAME = "STX_MODEL_INPUT_CALC"

    CAL_NUM_OF_WEEK_COL_NAME = "DAY_NUM_OF_WEEK"

