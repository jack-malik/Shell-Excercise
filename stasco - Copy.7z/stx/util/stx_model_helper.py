import os
import logging
import sys
import getopt
import datetime as dt
from stx.util.connections import pyodbc_connect
from stx.util.stx_db_manager import StxDbManager

logger_ = logging.getLogger(__name__)
logger_.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('[%(asctime)s]-[%(name)s]-[%(levelname)s]: %(message)s')
handler.setFormatter(formatter)
logger_.addHandler(handler)

STX_NATIONAL_GRID_MODEL_CD = 'NG'

class StxModelHelper(object):

    AT_WEIGHT_TEMP_KEY = 'ATt'
    WT_WEIGHT_WIND_KEY = 'Wt'
    ST_NORMAL_TEMP_KEY = 'St'

    ET_EFFECT_TEMP_KEY = 'Et'
    MAX_T0_MINUS_AT_TERM_KEY = 'max(0, T0-ATt)'
    MAX_WT_MINUS_W0_TERM_KEY = 'max(0,Wt-W0)'
    CWT_TERM_KEY = 'CWt'

    CWV_COLD_KEY = 'cold weather upturn'
    CWV_NORMAL_KEY = 'normal'
    CWV_TRANSITION_KEY = 'transition'
    CWV_SUMMER_KEY = 'summer cut-off'

    PARAM_ETW = "ETW"
    PARAM_I1 = "I1"
    PARAM_I2 = "I2"
    PARAM_I3 = "I3"
    PARAM_V0 = "V0"
    PARAM_V1 = "V1"
    PARAM_V2 = "V2"
    PARAM_Q = "q"
    PARAM_W0 = "W0"
    PARAM_T0 = "T0"
    PARAM_S0 = "S0"

    @staticmethod
    def calculate_at_weight_tempte__(as_of_date, country_cd, location_cd, dlw_factor_cache):

        # dlw_factor_cache[(as_of_date, country_cd, location_cd, factor_id)] = (factor_val, date_key)
        at_weight_val_date_tpl = dlw_factor_cache.get((as_of_date, country_cd, location_cd, 1), None)
        if not at_weight_val_date_tpl:
            raise ValueError("Unable to get At tempre for date-country-station:{}.{}.{}".format(as_of_date,
                                                                                                country_cd,
                                                                                                location_cd))
        return at_weight_val_date_tpl[0]

    @staticmethod
    def calculate_wt_weight_wind__(as_of_date, country_cd, location_cd, dlw_factor_cache):
        # dlw_factor_cache[(as_of_date, country_cd, location_cd, factor_id)] = (factor_val, date_key)
        wind_weight_val_date_tpl = dlw_factor_cache.get((as_of_date, country_cd, location_cd, 2), None)
        if not wind_weight_val_date_tpl:
            raise ValueError("Unable to get Wt wind speed for date-country-station:{}.{}.{}".format(as_of_date,
                                                                                                    country_cd,
                                                                                                    location_cd))
        return wind_weight_val_date_tpl[0]

    @staticmethod
    def get_normal_tempre_for_location__(as_of_date, country_cd, location_cd, norm_tempre_cache):

        # normal_tempte_cache[(as_of_date, country_cd, location_cd)] = temperature
        normal_tempre = norm_tempre_cache.get((as_of_date, country_cd, location_cd), None)
        if not normal_tempre:
            raise ValueError("Unable to get normal tempre for date-country-station:{}.{}.{}".format(as_of_date,
                                                                                                    country_cd,
                                                                                                    location_cd))
        return normal_tempre

    @staticmethod
    def calculate_et_effective_tempre__(as_of_date, country_cd, location_cd, dlw_factor_cache, model_param_cache,
                                        date_to_effect_tempre_cache):
        # ------------------------------------------------
        # Formula for Et = At * (1 - EWT) + (Et-1  * ETW)
        # ------------------------------------------------
        at_weight_val = 0
        at_weight_val_date_tpl = dlw_factor_cache.get((as_of_date, country_cd, location_cd, 1), None)
        if at_weight_val_date_tpl:
            at_weight_val = at_weight_val_date_tpl[0]

        as_of_date_minus_day = as_of_date + dt.timedelta(days=-1)
        effect_tempre_val_day_before = date_to_effect_tempre_cache.get(as_of_date_minus_day, 0)

        # param_cache[(param_cd, model_cd, country_cd, location_cd)] = (param_type, param_val, param_num_val)
        etw_param_tpl = model_param_cache.get((StxModelHelper.PARAM_ETW, STX_NATIONAL_GRID_MODEL_CD,
                                           country_cd, location_cd), None)
        if not etw_param_tpl:
            raise ValueError("Unable to get value for '{}' for:{}.{}.{}".format(StxModelHelper.PARAM_ETW,
                                                                                as_of_date,
                                                                                country_cd,
                                                                                location_cd))
        etw_param_val = etw_param_tpl[2]
        if not etw_param_val:
            raise ValueError("Invalid/empty value for '{}' for:{}.{}.{}".format(StxModelHelper.PARAM_ETW,
                                                                                as_of_date,
                                                                                country_cd,
                                                                                location_cd))
        effect_tempre = at_weight_val
        if effect_tempre_val_day_before:
            effect_tempre = at_weight_val * (1 - etw_param_val) + (effect_tempre_val_day_before * etw_param_val)
        date_to_effect_tempre_cache[as_of_date] = effect_tempre
        return effect_tempre

    @staticmethod
    def calculate_max_t0_minus_at_term__(model_param_cache, country_cd, location_cd, at_weight_temp):
        t0_param_tpl = model_param_cache.get((StxModelHelper.PARAM_T0, STX_NATIONAL_GRID_MODEL_CD,
                                               country_cd, location_cd), None)

        return max(0, t0_param_tpl[2] - at_weight_temp)

    @staticmethod
    def calculate_max_wt_minus_w0_term__(model_param_cache, country_cd, location_cd, wt_weight_wind):
        w0_param_tpl = model_param_cache.get((StxModelHelper.PARAM_W0, STX_NATIONAL_GRID_MODEL_CD,
                                               country_cd, location_cd), None)
        return max(0, wt_weight_wind - w0_param_tpl[2])

    @staticmethod
    def calculate_cwt_terms__(as_of_date, model_param_cache, country_cd, location_cd,
                             date_to_effect_tempre_cache, norm_tempre_cache, dmpl_entry_dict):

        max_wind_val = dmpl_entry_dict.get(StxModelHelper.MAX_WT_MINUS_W0_TERM_KEY)
        max_temp_val = dmpl_entry_dict.get(StxModelHelper.MAX_T0_MINUS_AT_TERM_KEY)

        # param_cache[(param_cd, model_cd, country_cd, location_cd)] = (param_type, param_val, param_num_val)
        param_i1_tpl = model_param_cache.get((StxModelHelper.PARAM_I1, STX_NATIONAL_GRID_MODEL_CD,
                                          country_cd, location_cd), None)
        param_i1_val = param_i1_tpl[2]
        effect_tempre = date_to_effect_tempre_cache.get(as_of_date, None)
        if not effect_tempre:
            raise ValueError("Unable to find effective temperature for date: {}".format(as_of_date))

        normal_tempre = norm_tempre_cache.get((as_of_date, country_cd, location_cd), None)
        if not normal_tempre:
            raise ValueError("Unable to find normal temperature for date: {}".format(as_of_date))

        param_i2_tpl = model_param_cache.get((StxModelHelper.PARAM_I2, STX_NATIONAL_GRID_MODEL_CD,
                                              country_cd, location_cd), None)
        param_i2_val = param_i2_tpl[2]
        param_s0_tpl = model_param_cache.get((StxModelHelper.PARAM_S0, STX_NATIONAL_GRID_MODEL_CD,
                                              country_cd, location_cd), None)
        param_s0_val = param_s0_tpl[2]
        cwt_term = param_i1_val * effect_tempre + (1 - param_i1_val) * normal_tempre - \
                   (param_i2_val * max_wind_val * max_temp_val) + (param_s0_val * 0)

        dmpl_entry_dict[StxModelHelper.CWT_TERM_KEY] = cwt_term

        # param_v0
        param_v0_tpl = model_param_cache.get((StxModelHelper.PARAM_V0, STX_NATIONAL_GRID_MODEL_CD,
                                              country_cd, location_cd), None)
        param_v0_val = param_v0_tpl[2]

        # param_v1
        param_v1_tpl = model_param_cache.get((StxModelHelper.PARAM_V1, STX_NATIONAL_GRID_MODEL_CD,
                                              country_cd, location_cd), None)
        param_v1_val = param_v1_tpl[2]

        # param_v2
        param_v2_tpl = model_param_cache.get((StxModelHelper.PARAM_V2, STX_NATIONAL_GRID_MODEL_CD,
                                              country_cd, location_cd), None)
        param_v2_val = param_v2_tpl[2]

        # param q
        param_q_tpl = model_param_cache.get((StxModelHelper.PARAM_Q, STX_NATIONAL_GRID_MODEL_CD,
                                             country_cd, location_cd), None)
        param_q_val = param_q_tpl[2]

        if param_v0_val > cwt_term:
            # CWVt = CWt + I3 * (CWt – V0 ) if V0 > CWt
            param_i3_tpl = model_param_cache.get((StxModelHelper.PARAM_I3, STX_NATIONAL_GRID_MODEL_CD,
                                                  country_cd, location_cd), None)
            param_i3_val = param_i3_tpl[2]
            dmpl_entry_dict[StxModelHelper.CWV_COLD_KEY] = cwt_term + (param_i3_val * (cwt_term - param_v0_val))
        else:
            dmpl_entry_dict[StxModelHelper.CWV_COLD_KEY] = None

        if param_v0_val <= cwt_term <= param_v1_val:
            # CWVt = CWt if V0 <= CWt <= V1
            dmpl_entry_dict[StxModelHelper.CWV_NORMAL_KEY] = cwt_term
        else:
            dmpl_entry_dict[StxModelHelper.CWV_NORMAL_KEY] = None

        if param_v1_val < cwt_term < param_v2_val:
            # CWVt = V1 + q * (CWt - V1) if V1 < CWt < V2
            dmpl_entry_dict[StxModelHelper.CWV_TRANSITION_KEY] = param_v1_val + (param_q_val * (cwt_term - param_v1_val))
        else:
            dmpl_entry_dict[StxModelHelper.CWV_TRANSITION_KEY] = None

        if param_v2_val <= cwt_term:
            # CWVt = V1 + q * (V2 - V1 ) if V2 <= CWt
            dmpl_entry_dict[StxModelHelper.CWV_SUMMER_KEY] = param_v1_val + (param_q_val * (param_v2_val - param_v1_val))
        else:
            dmpl_entry_dict[StxModelHelper.CWV_SUMMER_KEY] = None
        return

    @staticmethod
    def prepare_model_input_cache__(dlw_factor_cache, norm_tempre_cache, model_param_cache, from_db_dmpl_cache):
        """
        :param dlw_factor_cache: dictionary of date-location-weight-factors dictionary
        :param norm_tempre_cache: country-location-normal-temperature dictionary
        :param model_param_cache: country-location-model_param-val dictionary
        :param station_locat_cache: station-location dictionary
        :param from_db_dmpl_cache: date-model-param-location-calc-values dictionary by date
        :return:
        """

        date_to_effect_tempre_cache = {}
        extended_dmpl_cache = {}
        for (key, value) in from_db_dmpl_cache.items():
            # key = (CALENDAR_DATE,COUNTRY_CD,STATION_CD)
            # value=(PARAM_CD,PARAM_NUM_VAL)
            asof_date = key[0]
            country_cd = key[1]
            station_cd = key[2]
            if station_cd == 'NE':
                pass

            current_dmpl_dict = from_db_dmpl_cache.get(key, None)
            if not current_dmpl_dict:
                continue

            tmp_dmpl_entry_dict = {}
            at_weight_temp = None
            try:
                at_weight_temp = StxModelHelper.calculate_at_weight_tempte__(asof_date, country_cd, station_cd,
                                                                             dlw_factor_cache)
            except ValueError as ve:
                continue

            tmp_dmpl_entry_dict[StxModelHelper.AT_WEIGHT_TEMP_KEY] = at_weight_temp
            wt_weight_wind = None
            try:
                wt_weight_wind = StxModelHelper.calculate_wt_weight_wind__(asof_date, country_cd, station_cd,
                                                                           dlw_factor_cache)
            except ValueError as ve:
                continue

            tmp_dmpl_entry_dict[StxModelHelper.WT_WEIGHT_WIND_KEY] = wt_weight_wind

            tmp_dmpl_entry_dict[StxModelHelper.ST_NORMAL_TEMP_KEY] = \
                StxModelHelper.get_normal_tempre_for_location__(asof_date, country_cd, station_cd, norm_tempre_cache)

            tmp_dmpl_entry_dict[StxModelHelper.ET_EFFECT_TEMP_KEY] = \
                StxModelHelper.calculate_et_effective_tempre__(asof_date, country_cd, station_cd,
                                                               dlw_factor_cache, model_param_cache,
                                                               date_to_effect_tempre_cache)

            tmp_dmpl_entry_dict[StxModelHelper.MAX_T0_MINUS_AT_TERM_KEY] = \
                StxModelHelper.calculate_max_t0_minus_at_term__(model_param_cache, country_cd, station_cd,
                                                                at_weight_temp)


            tmp_dmpl_entry_dict[StxModelHelper.MAX_WT_MINUS_W0_TERM_KEY] = \
                StxModelHelper.calculate_max_wt_minus_w0_term__(model_param_cache, country_cd, station_cd,
                                                                wt_weight_wind)

            StxModelHelper.calculate_cwt_terms__(asof_date, model_param_cache, country_cd, station_cd,
                                                 date_to_effect_tempre_cache, norm_tempre_cache,
                                                 tmp_dmpl_entry_dict)


            # merge db-obtained parameter-value dictionary with computed values dictionary for this key
            extended_dmpl_cache[key] = {**current_dmpl_dict, **tmp_dmpl_entry_dict}

        return extended_dmpl_cache

