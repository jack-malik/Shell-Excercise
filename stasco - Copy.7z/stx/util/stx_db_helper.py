import os
import logging
import sys
import getopt
import datetime as dt
from stx.util.connections import pyodbc_connect
from stx.util.stx_db_manager import StxDbManager

logger_ = logging.getLogger(__name__)
logger_.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('[%(asctime)s]-[%(name)s]-[%(levelname)s]: %(message)s')
handler.setFormatter(formatter)
logger_.addHandler(handler)

STX_NATIONAL_GRID_MODEL_CD = 'NG'

class StxDbHelper(object):

    STX_INS_CALENDAR = "INSERT INTO {}.STX_CALENDAR (DATE_KEY,DATE_TYPE,CALENDAR_DATE,DAY_NUM_OF_WEEK," + \
                       "DAY_NUM_OF_MONTH,DAY_NUM_OF_QUARTER,DAY_NUM_OF_YEAR,DAY_NUM_ABSOLUTE," + \
                       "DAY_OF_WEEK_NAME,DAY_OF_WEEK_SHORT,JULIAN_DAY_NUM_OF_YEAR," + \
                       "JULIAN_DAY_NUM_ABSOLUTE,IS_WEEKDAY,IS_US_CIVIL_HOLIDAY,IS_LAST_DAY_OF_WEEK," + \
                       "IS_LAST_DAY_OF_MONTH,IS_LAST_DAY_OF_QUARTER,IS_LAST_DAY_OF_YEAR," + \
                       "WEEK_OF_YEAR_BEGIN_DATE,WEEK_OF_YEAR_BEGIN_DATE_KEY,WEEK_OF_YEAR_END_DATE," + \
                       "WEEK_OF_YEAR_END_DATE_KEY,WEEK_OF_MONTH_BEGIN_DATE," + \
                       "WEEK_OF_MONTH_BEGIN_DATE_KEY,WEEK_OF_MONTH_END_DATE," + \
                       "WEEK_OF_MONTH_END_DATE_KEY,WEEK_OF_QUARTER_BEGIN_DATE," + \
                       "WEEK_OF_QUARTER_BEGIN_DATE_KEY,WEEK_OF_QUARTER_END_DATE," + \
                       "WEEK_OF_QUARTER_END_DATE_KEY,WEEK_NUM_OF_MONTH,WEEK_NUM_OF_QUARTER," + \
                       "WEEK_NUM_OF_YEAR,MONTH_NUM_OF_YEAR,MONTH_NAME,MONTH_NAME_SHORT," + \
                       "MONTH_BEGIN_DATE,MONTH_BEGIN_DATE_KEY,MONTH_END_DATE,MONTH_END_DATE_KEY," + \
                       "QUARTER_NUM_OF_YEAR,QUARTER_BEGIN_DATE,QUARTER_BEGIN_DATE_KEY," + \
                       "QUARTER_END_DATE,QUARTER_END_DATE_KEY,YEAR_NUM,YEAR_BEGIN_DATE," + \
                       "YEAR_BEGIN_DATE_KEY,YEAR_END_DATE,YEAR_END_DATE_KEY,YYYYMMDD," + \
                       "LAST_ID, IS_ACTIVE) VALUES " + \
                       "({},'{}',{},{},{},{},{},{},'{}','{}',{},{},{}," + \
                       "{},{},{},{},{},{},{},{},{},{},{},{},{},{}," + \
                       "{},{},{},{},{},{},{},'{}','{}',{},{},{},{},{},{},{},{}," + \
                       "{},{},{},{},{},{},'{}', 'gitenio', {}) "

    STX_GET_CALENDAR_SQL_QUERY = "SELECT CALENDAR_DATE, DATE_KEY,DAY_NUM_OF_WEEK FROM {}.{} " + \
                                 "WHERE CALENDAR_DATE >= '{}' ORDER BY CALENDAR_DATE"

    CAL_DAY_NUM_OF_WEEK_COL_NAME = "DAY_NUM_OF_WEEK"

    CALENDAR_DAY_NUM_OF_WEEK_MAP = {
        1: "SUNDAY",
        2: "MONDAY",
        3: "TUESDAY",
        4: "WEDNESDAY",
        5: "THURSDAY",
        6: "FRIDAY",
        7: "SATURDAY"
    }
    CAL_MON_THU_WEEK_DAY_NUM_LIST = [2, 3, 4, 5]

    STX_GET_STATION_LOCATION_SQL_QUERY = "SELECT STATION_CD,STATION_NAME,EXTERNAL_NAME,STATION_TYPE," + \
                                         "COUNTRY_CD FROM {}.{} WHERE COUNTRY_CD='{}' AND IS_ACTIVE=1 " + \
                                         "AND STATION_NAME IS NOT NULL ORDER BY STATION_CD "

    SQL_GET_STX_MODEL_PARAMETER = "SELECT PARAM_CD,MODEL_CD,PARAM_NAME," + \
                                  "COUNTRY_CD,LOCATION_CD,PARAM_TYPE,PARAM_VAL,PARAM_NUM_VAL " + \
                                  "FROM {}.{} WHERE IS_ACTIVE=1 ORDER BY PARAM_CD"

    SQL_GET_STX_LOCATION_NORM_TEMPRE = "SELECT AS_OF_DATE, BUSINESS_DATE_ID,COUNTRY_CD,LOCATION_CD," + \
                                       "TEMPERATURE FROM {}.{} WHERE TEMPERATURE_TYPE='NORMAL' " + \
                                       "AND IS_ACTIVE=1 ORDER BY AS_OF_DATE"

    SQL_GET_STX_MODEL_FACTOR = "SELECT FACTOR_ID,FACTOR_CD,FACTOR_NAME,FACTOR_TYPE," + \
                               "EXTERNAL_NAME FROM {}.{} WHERE IS_ACTIVE=1 ORDER BY FACTOR_ID"

    SQL_GET_DATE_LOCAT_WEIGHT_FACTOR_VAL = "SELECT T1.AS_OF_DATE, T2.DATE_KEY, " + \
                                           "T1.COUNTRY_CD, T1.LOCATION_CD, " + \
                                           "T1.FACTOR_ID, T1.FACTOR_VAL FROM {}.{} T1, {}.{} T2 " + \
                                           "WHERE T1.IS_ACTIVE=1 AND T1.AS_OF_DATE=T2.CALENDAR_DATE " + \
                                           "AND T1.AS_OF_DATE >= '{}' " + \
                                           "AND T1.FACTOR_VAL IS NOT NULL " + \
                                           "AND T1.COUNTRY_CD != 'N/A' ORDER BY T1.AS_OF_DATE"

    SQL_GET_DATE_MODEL_LOCAT_PARAM_SET = "SELECT CAL.CALENDAR_DATE,	CAL.DATE_KEY," + \
                                         "WS.COUNTRY_CD," + \
                                         "WS.STATION_CD,MP.PARAM_CD,MP.PARAM_NUM_VAL " + \
                                         "FROM {}.{} MP," + \
                                         "{}.{} WS, {}.{} CAL "+ \
                                         "WHERE CAL.CALENDAR_DATE >= '{}' " + \
                                         "AND CAL.CALENDAR_DATE <= GETDATE() " + \
                                         "AND WS.COUNTRY_CD=MP.COUNTRY_CD " + \
                                         "AND WS.STATION_CD = MP.LOCATION_CD AND WS.STATION_TYPE=1 " + \
                                         "AND MODEL_CD='{}' AND WS.STATION_CD='NE'"


    STX_MODEL_PARAM_LOAD_SQL_SQLSERVER = "INSERT INTO {}.STX_MODEL_PARAMETER (" + \
        "PARAM_CD,MODEL_CD,PARAM_NAME,EXTERNAL_NAME,PARAM_TYPE,PARAM_NUM_VAL,COUNTRY_CD,LOCATION_CD, " + \
        "LAST_UPDATE, LAST_ID,IS_ACTIVE) VALUES ('{}','{}','{}','{}','{}',{},'{}'," + \
        "'{}', GETDATE(),'{}',{})"

    STX_GAS_DEMAND_DEFAULT_TYPE ="Demand"
    STX_GAS_DEMAND_DEFAULT_SUBTYPE = "DemandLDC"

    SQL_GET_STX_GAS_DEMAND = "SELECT AS_OF_DATE,DEMAND_TYPE,DEMAND_SUBTYPE,LOCATION_CD," + \
                             "DEMAND_AMT FROM {}.{} WHERE COUNTRY_CD='{}' AND DEMAND_TYPE='{}' " + \
                             "AND DEMAND_SUBTYPE='{}' AND AS_OF_DATE >= '{}' " + \
                             "AND AS_OF_DATE <= '{}' ORDER BY AS_OF_DATE "

    STX_GAS_DEMAND_SELECT_SQL = "WITH DD AS (" + \
                                "SELECT god.id, CONVERT(datetime2(0)," + \
                                "god.create_date) as create_date, god.actuals_date," + \
                                "god.cty, god.seriesId, god.value," + \
                                "ROW_NUMBER() OVER (PARTITION BY god.actuals_date," + \
                                "god.seriesid, god.cty ORDER BY god.id DESC) AS RowNumber " + \
                                "FROM ce.eugasopdata god, " + \
                                "ce.gas_stack_cty_mapping_prod_v cty_map " + \
                                "WHERE " + \
                                "god.actuals_date BETWEEN '{}' " + \
                                "AND  convert(date, GETUTCDATE()) " + \
                                "AND god.id >= (select max(min_id) " + \
                                "from ce.eugasopdata_min_id) " + \
                                "AND god.cty = cty_map.cty AND cty_map.is_cty='Y' " + \
                                "AND seriesId IN (" + \
                                "SELECT spa.seriesId from ce.eugasmeta_seriesperasset spa,"+\
                                "ce.gas_stack_cty_mapping_prod_v cty_map " + \
                                "WHERE spa.direction = cty_map.cty AND cty_map.is_cty = 'Y' "+\
                                "AND level = 3 AND spa.statusBlend = 'True' " + \
                                "AND spa.status = 'blend' AND spa.doEstimate = 'True' "+\
                                "AND spa.doFilter = 'True' AND spa.AssetSubtype = 'DemandLDC') " +\
                                ") " + \
                                "SELECT " + \
                                "SPA.assetType AS DEMAND_TYPE " + \
                                ",SPA.AssetSubtype as DEMAND_SUBTYPE " + \
                                ",SPA.assetId as EXTERNAL_ASSET_ID " + \
                                ",SPA.assetName as EXTERNAL_ASSET_NAME" + \
                                ",DD.seriesId AS EXTERNAL_SERIES_ID " + \
                                ",DD.cty AS COUNTRY " + \
                                ",DD.actuals_date AS AS_OF_DATE " + \
                                ",DD.value AS DEMAND_AMT " + \
                                "FROM DD, ce.eugasmeta_seriesperasset SPA WHERE RowNumber = 1 " + \
                                "AND DD.seriesId = spa.seriesId " + \
                                "AND DD.cty = 'GB' " + \
                                "AND SPA.assetId not in (55,56) " + \
                                "ORDER BY DD.actuals_date ASC, SPA.seriesId"

    STX_GAS_DEMAND_UPDATE_SQL = "INSERT INTO {}.{} (" + \
                                "AS_OF_DATE, BUSINESS_DATE_ID, DEMAND_TYPE, DEMAND_SUBTYPE, " + \
                                "EXTERNAL_ASSET_ID,EXTERNAL_SERIES_ID, COUNTRY_CD, LOCATION_CD," + \
                                "DEMAND_AMT, LAST_UPDATE, LAST_ID,IS_ACTIVE) " + \
                                "VALUES (CONVERT(date, '{}'), {}, '{}', '{}', '{}', '{}','{}','{}',{}," + \
                                "GETDATE(),'{}',{}) "

    SQL_DEACTIVATE_STX_GAS_DEMAND_TABLE = "BEGIN TRANSACTION;DELETE FROM {}.{};"
    SQL_DELETE_INACTIVE_STX_GAS_DEMAND_TABLE = "DELETE FROM {}.{} WHERE IS_ACTIVE=0; COMMIT;"

    SQL_DEACT_STX_LOCATION_TEMPERATURE = "BEGIN TRANSACTION;DELETE FROM {}.{};"
    SQL_DEL_INACT_STX_LOCAT_TEMPTE = "DELETE FROM {}.{} WHERE IS_ACTIVE=0; COMMIT;"

    SQL_DEACT_STX_LOCATION_WEIGHT_FACTOR = "BEGIN TRANSACTION;DELETE FROM {}.{};"
    SQL_DEL_INACT_STX_LOCAT_WEIGHT_FACTOR = "DELETE FROM {}.{} WHERE IS_ACTIVE=0; COMMIT;"

    SQL_INS_NG_STX_LOCATION_TEMPERATURE = "INSERT INTO {}.{} (" + \
                                          "AS_OF_DATE, BUSINESS_DATE_ID, COUNTRY_CD, LOCATION_CD," + \
                                          "TEMPERATURE_TYPE, TEMPERATURE_SOURCE,TEMPERATURE, LAST_UPDATE," + \
                                          "LAST_ID, IS_ACTIVE) VALUES (CONVERT(date, '{}'), {}," + \
                                          "'{}','{}','{}','{}',{},GETDATE(),'{}',{}) "

    SQL_INS_STX_LOCATION_WEIGHT_FACTOR = "INSERT INTO {}.{} (" + \
        "AS_OF_DATE, BUSINESS_DATE_ID, COUNTRY_CD, LOCATION_CD," + \
        "FACTOR_ID, FACTOR_VAL, LAST_UPDATE,LAST_ID, IS_ACTIVE) " + \
        "VALUES (CONVERT(date, '{}'), {}," + \
        "'{}','{}',{},{}, GETDATE(),'{}',{}) "

    SQL_INS_NG_MODEL_INPUT = "INSERT INTO {}.{} (" + \
                             "AS_OF_DATE, BUSINESS_DATE_ID, RUN_SEQ_NUM, MODEL_CD," + \
                             "COUNTRY_CD,LOCATION_CD,PARAM_ETW,PARAM_I1,PARAM_I2," + \
                             "PARAM_I3,PARAM_V0, PARAM_V1, PARAM_V2,PARAM_Q," + \
                             "PARAM_W0, PARAM_T0, PARAM_S0," + \
                             "CALC_ACTUAL_WEIGHTED_TEMPRE,CALC_EFFECTIVE_TEMPRE," + \
                             "CALC_WEIGHTED_WIND_SPEED, CALC_SEASON_NORM_TEMPRE," + \
                             "CALC_MAX_T0_MINUS_AT, CALC_MAX_WT_MINUS_W0," + \
                             "CALC_CW_TERM,CALC_CWV_COLD,CALC_CWV_NORMAL," + \
                             "CALC_CWV_TRANSITION,CALC_CWV_SUMMER," + \
                             "LAST_UPDATE,LAST_ID,IS_ACTIVE) VALUES (" + \
                             "CONVERT(date, '{}'),{},{},'{}','{}','{}'," + \
                             "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}," + \
                             "GETDATE(),'{}',{}) "

    DATE_MODEL_LOCAT_PARAM_CACHE_NAME = "DATE_MODEL_LOCAT_PARAM_CACHE"

    SQL_GET_NEXT_MODEL_RUN_SEQ_NUM = "SELECT NEXT VALUE FOR LDZ.MODEL_RUN_SEQ_NUM "

    @staticmethod
    def get_next_model_run_seq_number(connection_name=None):

        cursor = None
        conn = None
        sql_exec = StxDbHelper.SQL_GET_NEXT_MODEL_RUN_SEQ_NUM
        try:
            # Model DB connection            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            cursor.execute(sql_exec)
            for row in cursor:
                return row[0]

        except Exception as ex:
            msg = "Unexpected exception while retrieving next Model execution run number."
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        raise RuntimeError("Unexpected exception while retrieving next Model execution run number.")

    @staticmethod
    def cache_stasco_calendar(schema_name, start_date=None, connection_name=None):

        loaded = 0
        # connect to Stasco database and cache content of STX_CALENDAR into dict.
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")
        if not start_date:
            start_date = StxDbManager.DEFAULT_DATA_START_DATE
        sql = StxDbHelper.STX_GET_CALENDAR_SQL_QUERY
        try:
            # Model DB connection            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            sql_exec = sql.format(schema_name, StxDbManager.STX_CALENDAR_TBL_NAME, start_date)
            logger_.info("Caching content of STX_CALENDAR table ..")
            logger_.info("Executing SQL: {}".format(sql_exec))
            cursor.execute(sql_exec)
            calendar_cache = {}
            for row in cursor:
                calendar_date = row[0]
                calendar_date_str = calendar_date.strftime('%Y-%m-%d')
                calendar_date_key = row[1]
                cal_day_num_of_week = row[2]
                tmp_dict = {StxDbManager.CAL_DATE_KEY: calendar_date_key,
                            StxDbManager.CAL_CALENDAR_DATE: calendar_date,
                            StxDbManager.CAL_CALENDAR_DATE_STR: calendar_date_str,
                            StxDbManager.CAL_NUM_OF_WEEK_COL_NAME: cal_day_num_of_week
                            }
#                calendar_cache[calendar_date_str] = tmp_dict
                calendar_cache[calendar_date] = tmp_dict
                loaded += 1

        except Exception as ex:
            msg = "Exception while caching {} table. Msg: {}".format(StxDbManager.STX_CALENDAR_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass

        logger_.info("Cached {} calendar records successfully ..".format(loaded))
        return calendar_cache

    @staticmethod
    def cache_stasco_station_location(schema_name, country, connection_name=None):

        processed = 0
        station_cache = {}
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")

        try:
            # connect to Stasco database and cache content of STX_CALENDAR into dict.
            # Model DB connection            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()

            sql = StxDbHelper.STX_GET_STATION_LOCATION_SQL_QUERY

            sql_exec = sql.format(schema_name, StxDbManager.STX_WEATHER_STATION_TBL_NAME, country)
            logger_.info("Caching content of '{}' table ..".format(StxDbManager.STX_WEATHER_STATION_TBL_NAME))
            logger_.info("Executing SQL: {}".format(sql_exec))
            cursor.execute(sql_exec)
            for row in cursor:
                # STATION_CD,STATION_NAME,EXTERNAL_NAME,STATION_TYPE,COUNTRY_CD
                station_cd = row[0]
                station_name = row[1]
                external_name = row[2]
                station_type = row[3]
                country_cd = row[4]
                station_cache[(station_cd, station_name, station_type)] = (external_name, country_cd)
                processed += 1

        except Exception as ex:
            msg = "Exception while caching {} table. Msg: {}".format(StxDbManager.STX_CALENDAR_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass

        logger_.info("Cached {} weather station records successfully ..".format(processed))
        return station_cache

    @staticmethod
    def cache_stasco_model_parameter(schema_name, start_date, as_of_date, connection_name=None):

        processed = 0
        sql = StxDbHelper.SQL_GET_STX_MODEL_PARAMETER
        param_cache = {}
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")
        try:
            sql_exec = sql.format(schema_name, StxDbManager.STX_MODEL_PARAMETER_TBL_NAME)
            logger_.info("Caching content of '{}' table ..".format(StxDbManager.STX_WEATHER_STATION_TBL_NAME))
            logger_.info("Executing SQL: {}".format(sql_exec))
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            cursor.execute(sql_exec)
            for row in cursor:
                # PARAM_CD,MODEL_CD,PARAM_NAME, COUNTRY_CD,LOCATION_CD,PARAM_TYPE,PARAM_VAL,PARAM_NUM_VAL
                param_cd = row[0]
                model_cd = row[1]
                param_name = row[2]
                country_cd = row[3]
                location_cd = row[4]
                param_type = row[5]
                param_val = row[6]
                param_num_val = row[7]
                param_cache[(param_cd, model_cd, country_cd, location_cd)] = (param_type, param_val, param_num_val)
                processed += 1

        except Exception as ex:
            msg = "Exception caching {} table. Msg: {}".format(StxDbManager.STX_MODEL_PARAMETER_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Cached {} model parameter values successfully ..".format(processed))
        return param_cache

    @staticmethod
    def cache_country_location_norm_tempre(schema_name, start_date, as_of_date, connection_name=None):

        processed = 0
        sql = StxDbHelper.SQL_GET_STX_LOCATION_NORM_TEMPRE
        normal_tempte_cache = {}
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")
        try:
            sql_exec = sql.format(schema_name, StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME)
            logger_.info("Caching content of '{}' table ..".format(StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME))
            logger_.info("Executing SQL: {}".format(sql_exec))
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            cursor.execute(sql_exec)
            for row in cursor:
                # AS_OF_DATE,BUSINESS_DATE_ID,COUNTRY_CD,LOCATION_CD,TEMPERATURE
                as_of_date = row[0]
                business_date_id = row[1]
                country_cd = row[2]
                location_cd = row[3]
                temperature = row[4]
                normal_tempte_cache[(as_of_date, country_cd, location_cd)] = temperature
                processed += 1

        except Exception as ex:
            msg = "Exception caching {} table. {}".format(StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Cached {} model parameter values successfully ..".format(processed))
        return normal_tempte_cache


    @staticmethod
    def cache_date_location_weight_factor(schema_name, start_date, as_of_date, connection_name=None):

        processed = 0
        sql = StxDbHelper.SQL_GET_DATE_LOCAT_WEIGHT_FACTOR_VAL
        dlw_factor_cache = {}
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")
        cursor = None
        conn = None
        try:
            sql_exec = sql.format(schema_name, StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME,
                                  schema_name, StxDbManager.STX_CALENDAR_TBL_NAME, start_date)
            logger_.info("Caching content of '{}' table ..".format(StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME))
            logger_.info("Executing SQL: {}".format(sql_exec))
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            cursor.execute(sql_exec)
            for row in cursor:
                # AS_OF_DATE, COUNTRY_CD, LOCATION_CD, FACTOR_ID, FACTOR_VAL
                as_of_date = row[0]
                date_key = row[1]
                country_cd = row[2]
                location_cd = row[3]
                factor_id = row[4]
                factor_val = row[5]
                dlw_factor_cache[(as_of_date, country_cd, location_cd, factor_id)] = (factor_val, date_key)
                processed += 1

        except Exception as ex:
            msg = "Exception caching {} table. {}".format(StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)

        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Cached {} location-weight-factor values successfully ..".format(processed))
        return dlw_factor_cache

    @staticmethod
    def cache_date_model_param_location(schema_name, start_date, as_of_date, connection_name=None):
        """
        :param schema_name:
        :param connection_name:
        :return:
        """
        processed = 0
        sql = StxDbHelper.SQL_GET_DATE_MODEL_LOCAT_PARAM_SET
        dmpl_cache = {}
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")
        cursor = None
        conn = None
        try:
            sql_exec = sql.format(schema_name, StxDbManager.STX_MODEL_PARAMETER_TBL_NAME,
                                  schema_name, StxDbManager.STX_WEATHER_STATION_TBL_NAME,
                                  schema_name, StxDbManager.STX_CALENDAR_TBL_NAME,
                                  start_date,
                                  STX_NATIONAL_GRID_MODEL_CD)

            logger_.info("Caching content of date-model-parameter-location data ..")
            logger_.info("Executing SQL: {}".format(sql_exec))
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            cursor.execute(sql_exec)
            for row in cursor:
                # CALENDAR_DATE, DATE_KEY, COUNTRY_CD, STATION_CD, MP.PARAM_CD, MP.PARAM_NUM_VAL
                as_of_date = row[0]
                date_key = row[1]
                country_cd = row[2]
                station_cd = row[3]
                logger_.info("STATION: {} ..".format(station_cd))
                if station_cd == "NE":
                    pass

                param_cd = row[4]
                param_num_val = row[5]
                date_entry_dict = dmpl_cache.get((as_of_date, country_cd, station_cd), None)
                if not date_entry_dict:
                    date_entry_dict = {}
                date_entry_dict[param_cd] = param_num_val
                dmpl_cache[(as_of_date, country_cd, station_cd)] = date_entry_dict
                if station_cd == 'NE':
                    pass
                processed += 1

        except Exception as ex:
            msg = "Exception caching {} table. {}".format(StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Cached {} location-weight-factor values successfully ..".format(processed))
        return dmpl_cache

    @staticmethod
    def get_min_gas_demand_as_of_date_date():
        return dt.datetime.strptime('2012-10-01', '%Y-%m-%d')

    @staticmethod
    def get_max_gas_demand_as_of_date():
        return dt.datetime.now()

    @staticmethod
    def cache_gas_demand(schema_name, country, start_date=None, as_of_date=None, connection_name=None):

        processed = 0
        sql = StxDbHelper.SQL_GET_STX_GAS_DEMAND
        date_to_gas_demand_cache = {}
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            raise RuntimeError("Detected no environment value set for STASCO_DB_NAME. Aborting")
        cursor = None
        conn = None
        if not start_date:
            start_date = StxDbHelper.get_min_gas_demand_as_of_date()
        start_date_str = start_date.strftime('%Y-%m-%d')

        as_of_date_str = dt.datetime.now().strftime('%Y-%m-%d')
        if not as_of_date:
            as_of_date = dt.datetime.now().strftime('%Y-%m-%d')

        try:
            sql_exec = sql.format(schema_name, StxDbManager.STX_GAS_DEMAND_TBL_NAME,
                                  country, StxDbHelper.STX_GAS_DEMAND_DEFAULT_TYPE,
                                  StxDbHelper.STX_GAS_DEMAND_DEFAULT_SUBTYPE,
                                  start_date_str, as_of_date_str)


            logger_.info("Caching gas deman from '{}' to '{}'content of date-model-parameter-location data ..")
            logger_.info("Executing SQL: {}".format(sql_exec))
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            cursor.execute(sql_exec)
            for row in cursor:
                # CALENDAR_DATE,DATE_KEY,RUN_SEQ_NUM,MODEL_CD,COUNTRY_CD,STATION_CD,PARAM_CD,PARAM_NUM_VAL
                as_of_date = row[0]
                station_cd = row[3]
                amount_val = row[4]
                date_to_gas_demand_cache[(as_of_date, station_cd)] = amount_val
                processed += 1

        except Exception as ex:
            msg = "Exception caching {} table. {}".format(StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME, ex)
            logger_.error(msg)
            raise RuntimeError(msg)
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Cached {} location-weight-factor values successfully ..".format(processed))
        return date_to_gas_demand_cache


    @staticmethod
    def get_country_station_name_list(station_data_cache):
        # station_cache[(station_cd, station_name, station_type)] = (external_name, country_cd)
        station_name_set = set()
        for (key, value) in station_data_cache.items():
            station_name_set.add(key[1])
        return list(station_name_set)


def core__(entity_to_cache_list, asof_date, connection_name, schema_name='LDZ',
           is_active=True):
    if StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME in entity_to_cache_list and not asof_date:
        logger_.error("Provide -a <as of date> start date parameter to cache data .. ")
        return -1

    asof_date = asof_date.date()
    dlw_factor_cache = None
    norm_tempte_cache = None
    model_param_cache = None
    calendar_data_cache = None
    calendar_data_cache = None
    dmpl_cache = None
    for entity in entity_to_cache_list:
        if entity == StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME:
            dlw_factor_cache = StxDbHelper.cache_date_locat_weight_factor(schema_name, asof_date,
                                                                          connection_name=None)
        elif entity == StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME:
            norm_tempte_cache = StxDbHelper.cache_country_location_norm_tempte(schema_name,
                                                                               connection_name=connection_name)
        elif entity == StxDbManager.STX_MODEL_PARAMETER_TBL_NAME:
            model_param_cache = StxDbHelper.cache_stasco_model_parameter(schema_name,
                                                                         connection_name=None)
        elif entity == StxDbManager.STX_CALENDAR_TBL_NAME:
            calendar_data_cache = StxDbHelper.cache_stasco_calendar(schema_name,
                                                                    connection_name=connection_name)
        elif entity == StxDbManager.STX_WEATHER_STATION_TBL_NAME:
            calendar_data_cache = StxDbHelper.cache_stasco_station_location(schema_name,
                                                                            connection_name=connection_name)
        elif entity == StxDbHelper.DATE_MODEL_LOCAT_PARAM_CACHE_NAME:
            dmpl_cache = StxDbHelper.cache_date_model_param_location(schema_name, asof_date, connection_name=None)

    return 0


def main(argv):

    table = ''
    asof = ''
    try:
        opts, args = getopt.getopt(argv, "ht:a:", ["table=", "asof="])
    except getopt.GetoptError as er:
        print(er)
        print("{} -t <table> -a <asof>".format(__name__))
        return -2

    for opt, arg in opts:
        if opt == '-h':
            print("{}.py -t <table> -a <asof>".format(__name__))
            return 1
        if opt in ("-t", "--table"):
            table = arg
        elif opt in ("-a", "--asof"):
            asof = arg

    print("Tables to load: {}".format(table))
    print("Run asof      : {}".format(asof))

    table_to_cache_list = None
    if table:
        table_to_cache_list = table.replace(' ', '').split(',')

    run_as_of_dt = None
    if asof:
        run_as_of_dt = dt.datetime.strptime(asof, '%Y-%m-%d')

    if not table:
        logger_.info("No tables to load data specified. Exiting ..")
        return 0
    connection_name = os.getenv('STASCO_DB_NAME', None)
    if not connection_name:
        logger_.error("STASCO database name undefined. Define 'STASCO_DB_NAME env. variable.")
        return -1
    logger_.info("Starting load for table(s): {} .. ".format(table))
    home_dir = os.getenv('STASCO_HOME', None)
    if not home_dir:
        logger_.error("STASCO HOME directory not set. Define 'STASCO_HOME env. variable.")
        return -1

    return core__(table_to_cache_list, run_as_of_dt, connection_name)


if __name__ == '__main__':

    ret_cd = main(sys.argv[1:])
    sys.exit(ret_cd)
