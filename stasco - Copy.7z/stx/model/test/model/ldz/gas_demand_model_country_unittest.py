# -*- coding: utf-8 -*-

import unittest
from src.lib.demand_model_execution import *

MI = ModelInputs(dt_from='2019-03-01', country='UK', issue='0',
                    dt_to='2019-03-01', features_to_remove='', target='actual_demand_d',
                    asof_dt=dt.datetime.today().strftime('%Y-%m-%d'), model_inputs_tbl='model_inputs_uk',
                    metg_stations="Albemarle,Birmingham,Bristol,Cardiff,Glasgow,London,Manchester,Nottingham,Southampton",
                    metd_stations="Albemarle - Newcastle,Birmingham,Bristol,Cardiff,Glasgow,London Heathrow,Manchester,Nottingham,Southampton",
                    metg_to_metd_map='{"Albemarle":"Albemarle - Newcastle", "London":"London Heathrow"}',
                    solar_stations="'Bristol','Heathrow','Cardiff','Durham','Southampton','Birmingham','Manchester','Nottingham'",
                    mode="Back Test")


class ModelInputsTest(unittest.TestCase):

    def load_inputs_from_db_test(self):
        inputs = MI.load_inputs_from_db()
        assert(inputs.timestamp_utc == '2019-03-01')

    def get_demand_actuals_ce_test(self):
        pass

    def get_snd_ng_test(self):
        pass

class DemandModelTest(unittest.TestCase):
    pass

class DemandModelPostProcessingTest(unittest.TestCase):
    pass

class DemandModelExecutionTest(unittest.TestCase):
    pass

