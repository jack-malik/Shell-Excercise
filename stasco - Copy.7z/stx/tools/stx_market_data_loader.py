import os
import getopt
import logging
import datetime as dt
import sys
from decimal import Decimal, getcontext

from stx.util.connections import pyodbc_connect
from stx.util.stx_db_manager import StxDbManager
from stx.util.stx_db_helper import StxDbHelper

logger_ = logging.getLogger(__name__)
logger_.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('[%(asctime)s]-[%(name)s]-[%(levelname)s]: %(message)s')
handler.setFormatter(formatter)
logger_.addHandler(handler)

STX_TABLE_TO_FILE_MAP = {StxDbManager.STX_CALENDAR_TBL_NAME: "STX_CALENDAR.csv",
                         StxDbManager.STX_MODEL_PARAMETER_TBL_NAME: "STX_MODEL_PARAMETER.csv",
                         StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME: "STX_NATIONAL-GRID-NORMAL-TEMP-UK.csv",
                         StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME: "STX_LOCATION_WEIGHT_FACTOR_INPUT.csv"
                         }

WEATHER_TEMPRE_FACTOR_ID = 1
WEATHER_WIND_FACTOR_ID = 2
WEATHER_SOLAR_FACTOR_ID = 3

SYS_TRAD_WT_FACTOR_LOCATION_COL_NAME = "location_name"
SYS_TRAD_WT_FACTOR_GAS_DAY_COL_NAME = "gas_day"
SYS_TRAD_WT_FACTOR_SRC_COL_NAME = "Source"
SYS_TRAD_WT_FACTOR_TEMPRE_COL_NAME = "Temp"
SYS_TRAD_WT_FACTOR_WIND_COL_NAME = "Wind"

SYS_TRADING_WEDNESDAY_QUERY = " With metg_data_temp as (  " + \
" SELECT a.location_name, a.timestamp_shifted as [Shifted_DateTime], dateadd(hour, -5, a.timestamp_shifted) as pseudo_DateTime, a.[value], cast(round(b.tt_weight,2) as decimal(8,2)) as tt_weight, round((a.[value] * b.tt_weight),2) as weighted_temp   " + \
" FROM [mdk].[archive_data_source_metg_obs_hourly_tt_transformed] a   " + \
" left join [dmd_model].[STX_TIME_WEATHER_PARAM_WEIGHT] b   " + \
" on datepart(hour, a.timestamp_shifted) = datepart(hour, b.as_of_hour)   " + \
" where country = 'GB'   " + \
" and cast(dateadd(hour, -5, a.timestamp_shifted) as date) > '1969-12-31'   " + \
" and b.is_active = 1   " + \
" and a.ind in ('TT')   " + \
"and a.location_name in ('{}')),   " + \
" metg_data_temp_soton as (  " + \
" select a.location_name, a.timestamp_shifted as [Shifted_DateTime], dateadd(hour, -5, a.timestamp_shifted) as pseudo_DateTime, a.[value], cast(round(b.tt_weight,2) as decimal(8,2)) as tt_weight, round((a.[value] * b.tt_weight),2) as weighted_temp   " + \
" from mdk.archive_data_source_metg_obs_hourly_tt_transformed_southampton a   " + \
" left join [dmd_model].[STX_TIME_WEATHER_PARAM_WEIGHT] b   " + \
" on datepart(hour, a.timestamp_shifted) = datepart(hour, b.as_of_hour)   " + \
" where cast(dateadd(hour, -5, a.timestamp_shifted) as date) > '{}'   " + \
" and b.is_active = 1),   " + \
" metg_temp_join as(  " + \
" select * from metg_data_temp  " + \
" union all  " + \
" select * from metg_data_temp_soton),  " + \
" metg_temp_daily as (  " + \
" select location_name, cast(pseudo_DateTime as date) as gas_day, cast(round(sum(weighted_temp),2) as decimal(8,2)) as Temp from metg_temp_join group by cast(pseudo_Datetime as date), location_name),   " + \
" metg_data_wind as (  " + \
" SELECT a.location_name, a.timestamp_shifted as [Shifted_DateTime], dateadd(hour, -5, a.timestamp_shifted) as pseudo_DateTime, a.[value], b.wind_weight, a.[value] * b.wind_weight as weighted_wind FROM [mdk].[archive_data_source_metg_obs_hourly_wnds_transformed] a left join [dmd_model].[STX_TIME_WEATHER_PARAM_WEIGHT] b  " + \
" on datepart(hour, a.timestamp_shifted) = datepart(hour, b.as_of_hour)  " + \
" where country = 'GB'  " + \
" and cast(dateadd(hour, -5, a.timestamp_shifted) as date) > '{}'  " + \
" and b.is_active = 1  " + \
" and a.ind in ('WNDS')  " + \
"and a.location_name in ('{}') ),  " + \
" metg_data_wind_soton as(  " + \
" select a.location_name, a.timestamp_shifted as [Shifted_DateTime], dateadd(hour, -5, a.timestamp_shifted) as pseudo_DateTime, (a.[value] * 0.868976) as [value], cast(round(b.tt_weight,2) as decimal(8,2)) as tt_weight, round(((a.[value]* 0.868976) * b.tt_weight),2) as weighted_temp  " + \
" from mdk.archive_data_source_metg_obs_hourly_tt_transformed_southampton_wind a  " + \
" left join [dmd_model].[STX_TIME_WEATHER_PARAM_WEIGHT] b  " + \
" on datepart(hour, a.timestamp_shifted) = datepart(hour, b.as_of_hour)  " + \
" where cast(dateadd(hour, -5, a.timestamp_shifted) as date) > '{}' and b.is_active = 1),  " + \
" metg_wind_join as (  " + \
" select * from metg_data_wind  " + \
" union all  " + \
" select * from metg_data_wind_soton),  " + \
" metg_wind_daily as (  " + \
" select location_name, cast(pseudo_DateTime as date) as gas_day, cast(round(sum(weighted_wind),2) as decimal(8,2)) as Wind from metg_wind_join group by cast(pseudo_Datetime as date), location_name),  " + \
" metg_data as (  " + \
" select a.location_name, a.gas_day, 'METG' as [Source], round(a.Temp,1) as Temp, round(b.Wind,1) as Wind  " + \
" from metg_temp_daily a  " + \
" left join metg_wind_daily b  " + \
" on a.location_name = b.location_name  " + \
" and a.gas_day = b.gas_day  " + \
" AND A.GAS_DAY <= '2018-12-31'),  " + \
" metd_data as (  " + \
" select ind, location_name, timestamp_shifted, dateadd(hour, -5, timestamp_shifted) as pseudo_Datetime,([value] * 0.868976) as [Value] from [mdk].[archive_data_source_api_observations] where location_name in ('London Heathrow','Rostherne','Nottingham','Glasgow','Bristol','Cardiff','Albemarle - Newcastle', 'Birmingham') and ind in ('TT', 'FF')),  " + \
" metd_pivot_data as (  " + \
" select *   " + \
" from metd_data t  " + \
" PIVOT(  " + \
" AVG(VALUE) FOR IND IN (TT,FF)  " + \
") AS PIVOT_TABLE),  " + \
" metd_data_join as (  " + \
" select a.location_name, a.pseudo_Datetime, round((a.[TT] * b.tt_weight),2) as weighted_temp, a.[FF] * b.wind_weight as weighted_wind from metd_pivot_data a left join [dmd_model].[STX_TIME_WEATHER_PARAM_WEIGHT] b  " + \
" on datepart(hour, a.timestamp_shifted) = datepart(hour, b.as_of_hour)  " + \
" where cast(pseudo_Datetime as date) >= '2019-01-01'  " + \
" and b.is_active = 1),  " + \
"metd_daily as (  " + \
" select location_name, cast(pseudo_DateTime as date) as gas_day, 'METD' as [Source], cast(round(sum(weighted_temp),2) as decimal(8,2)) as Temp, cast(round(sum(weighted_wind),2) as decimal(8,2)) as Wind from metd_data_join group by cast(pseudo_Datetime as date), location_name),  " + \
" All_data as (  " + \
" select * from metg_data  " + \
" union all  " + \
" select * from metd_daily)  " + \
" select * from All_data order by gas_day asc  "




class MarketDataLoader(object):

    @staticmethod
    def db_load_calendar(self, schema_name, file_name, connection_name, is_active=1):

        logger_.info("Loading table '{}' from file: {}".format(StxDbManager.STX_CALENDAR_TBL_NAME,
                                                               file_name))
        cursor = None
        sql = StxDbHelper.STX_INS_CALENDAR
        count = 0
        loaded = 0
        conn = None
        try:
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            with open(file_name, "r") as file_handle:
                for line in file_handle:
                    if count == 0:
                        count += 1
                        continue
                    # example: # DATE_KEY,DATE_TYPE,FULL_DATE,DAY_NUM_OF_WEEK,
                    #            DAY_NUM_OF_MONTH,DAY_NUM_OF_QUARTER,DAY_NUM_OF_YEAR,
                    #            DAY_NUM_ABSOLUTE,DAY_OF_WEEK_NAME,DAY_OF_WEEK_ABBREVIATION,
                    #            JULIAN_DAY_NUM_OF_YEAR,JULIAN_DAY_NUM_ABSOLUTE,IS_WEEKDAY,
                    #            IS_US_CIVIL_HOLIDAY,IS_LAST_DAY_OF_WEEK,IS_LAST_DAY_OF_MONTH,
                    #            IS_LAST_DAY_OF_QUARTER,IS_LAST_DAY_OF_YEAR,WEEK_OF_YEAR_BEGIN_DATE,
                    #            WEEK_OF_YEAR_BEGIN_DATE_KEY,WEEK_OF_YEAR_END_DATE,
                    #            WEEK_OF_YEAR_END_DATE_KEY,WEEK_OF_MONTH_BEGIN_DATE,
                    #            WEEK_OF_MONTH_BEGIN_DATE_KEY,WEEK_OF_MONTH_END_DATE,
                    #            WEEK_OF_MONTH_END_DATE_KEY,WEEK_OF_QUARTER_BEGIN_DATE,
                    #            WEEK_OF_QUARTER_BEGIN_DATE_KEY,WEEK_OF_QUARTER_END_DATE,
                    #            WEEK_OF_QUARTER_END_DATE_KEY,WEEK_NUM_OF_MONTH,WEEK_NUM_OF_QUARTER,
                    #            WEEK_NUM_OF_YEAR,MONTH_NUM_OF_YEAR,MONTH_NAME,MONTH_NAME_ABBREVIATION,
                    #            MONTH_BEGIN_DATE,MONTH_BEGIN_DATE_KEY,MONTH_END_DATE,MONTH_END_DATE_KEY,
                    #            QUARTER_NUM_OF_YEAR,QUARTER_NUM_OVERALL,QUARTER_BEGIN_DATE,
                    #            QUARTER_BEGIN_DATE_KEY,QUARTER_END_DATE,QUARTER_END_DATE_KEY,
                    #            YEAR_NUM,YEAR_BEGIN_DATE,YEAR_BEGIN_DATE_KEY,YEAR_END_DATE,
                    #            YEAR_END_DATE_KEY,YYYYMMDD
                    count += 1
                    tmp_arr = line.rstrip('\n').split(',')
                    if len(tmp_arr) < 7:
                        continue

                    date_key = int(tmp_arr[0])
                    date_type = tmp_arr[1]

                    full_date = "CONVERT(datetime, '{}', 103)".format(tmp_arr[2])
                    day_num_of_week = int(tmp_arr[3])
                    day_num_of_month = int(tmp_arr[4])
                    day_num_of_quarter = int(tmp_arr[5])
                    day_num_of_year = int(tmp_arr[6])
                    day_num_absolute = int(tmp_arr[7])
                    day_of_week_name = tmp_arr[8]
                    day_of_week_abbreviation = tmp_arr[9]
                    julian_day_num_of_year = int(tmp_arr[10])
                    julian_day_num_absolute = Decimal(tmp_arr[11])

                    is_weekday = 0
                    if tmp_arr[12] == 'Y':
                        is_weekday = 1
                    is_us_civil_holiday = 0
                    if tmp_arr[13] == 'Y':
                        is_us_civil_holiday = 1
                    is_last_day_of_week = 0
                    if tmp_arr[14] == 'Y':
                        is_last_day_of_week = 1
                    is_last_day_of_month = 0
                    if tmp_arr[15] == 'Y':
                        is_last_day_of_month = 1
                    is_last_day_of_quarter = 0
                    if tmp_arr[16] == 'Y':
                        is_last_day_of_quarter = 1
                    is_last_day_of_year = 0
                    if tmp_arr[17] == 'Y':
                        is_last_day_of_year = 1

                    week_of_year_begin_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[18])
                    week_of_year_begin_date_key = int(tmp_arr[19])

                    week_of_year_end_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[20])
                    week_of_year_end_date_key = int(tmp_arr[21])

                    week_of_month_begin_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[22])
                    week_of_month_begin_date_key = int(tmp_arr[23])

                    week_of_month_end_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[24])
                    week_of_month_end_date_key = int(tmp_arr[25])

                    week_of_quarter_begin_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[26])
                    week_of_quarter_begin_date_key = int(tmp_arr[27])

                    week_of_quarter_end_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[28])
                    week_of_quarter_end_date_key = int(tmp_arr[29])
                    week_num_of_month = int(tmp_arr[30])
                    week_num_of_quarter = int(tmp_arr[31])
                    week_num_of_year = int(tmp_arr[32])
                    month_num_of_year = int(tmp_arr[33])
                    month_name = tmp_arr[34]
                    month_name_abbreviation = tmp_arr[35]
                    month_begin_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[36])
                    month_begin_date_key = int(tmp_arr[37])

                    month_end_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[38])
                    month_end_date_key = int(tmp_arr[39])

                    quarter_num_of_year = int(tmp_arr[40])
                    quarter_begin_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[41])
                    quarter_begin_date_key = int(tmp_arr[42])

                    quarter_end_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[43])
                    quarter_end_date_key = int(tmp_arr[44])

                    year_num = int(tmp_arr[45])
                    year_begin_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[46])
                    year_begin_date_key = int(tmp_arr[47])

                    year_end_date = " CONVERT(datetime, '{}', 103)".format(tmp_arr[48])
                    year_end_date_key = int(tmp_arr[49])
                    yyyymmdd = tmp_arr[50]

                    sql_exec = sql.format(schema_name,
                                          date_key,
                                          date_type,
                                          full_date,
                                          day_num_of_week,
                                          day_num_of_month,
                                          day_num_of_quarter,
                                          day_num_of_year,
                                          day_num_absolute,
                                          day_of_week_name,
                                          day_of_week_abbreviation,
                                          julian_day_num_of_year,
                                          julian_day_num_absolute,
                                          is_weekday,
                                          is_us_civil_holiday,
                                          is_last_day_of_week,
                                          is_last_day_of_month,
                                          is_last_day_of_quarter,
                                          is_last_day_of_year,
                                          week_of_year_begin_date,
                                          week_of_year_begin_date_key,
                                          week_of_year_end_date,
                                          week_of_year_end_date_key,
                                          week_of_month_begin_date,
                                          week_of_month_begin_date_key,
                                          week_of_month_end_date,
                                          week_of_month_end_date_key,
                                          week_of_quarter_begin_date,
                                          week_of_quarter_begin_date_key,
                                          week_of_quarter_end_date,
                                          week_of_quarter_end_date_key,
                                          week_num_of_month,
                                          week_num_of_quarter,
                                          week_num_of_year,
                                          month_num_of_year,
                                          month_name,
                                          month_name_abbreviation,
                                          month_begin_date,
                                          month_begin_date_key,
                                          month_end_date,
                                          month_end_date_key,
                                          quarter_num_of_year,
                                          quarter_begin_date,
                                          quarter_begin_date_key,
                                          quarter_end_date,
                                          quarter_end_date_key,
                                          year_num,
                                          year_begin_date,
                                          year_begin_date_key,
                                          year_end_date,
                                          year_end_date_key,
                                          yyyymmdd,
                                          is_active)

                    logger_.debug("Executing SQL: {}".format(sql_exec))
                    cursor.execute(sql_exec)
                    loaded += 1
                    if count % 250 == 0:
                        logger_.info("Processed {} calendar data records .. Currently loaded {} ..".format(count-1, loaded))

        except Exception as ex:
            logger_.error("Unexpected exception while loading data from {}. Msg: {}".format(file_name, ex))
            return -1

        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass

        logger_.info("Processed {} data records from file '{}'. Loaded {} successfully".format(count-1,
                                                                                               file_name,
                                                                                               loaded))
        return loaded

    @staticmethod
    def db_load_model_param(schema_name, file_name, connection_name, is_active=1):
        """
        :param schema_name:
        :param file_name:
        :param connection_name:
        :param is_active:
        :return:
        """
        cursor = None
        sql = StxDbHelper.STX_MODEL_PARAM_LOAD_SQL_SQLSERVER
        count = 0
        loaded = 0
        conn = None
        logger_.info("Loading table '{}' from file: {} ..".format(StxDbManager.STX_MODEL_PARAMETER_TBL_NAME,
                                                                  file_name))

        try:
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            with open(file_name, "r") as file_handle:
                for line in file_handle:
                    if count == 0:
                        count += 1
                        continue
                    # header: PARAM_CD	MODEL_CD	PARAM_NAME	EXTERNAL_NAME	PARAM_TYPE	COUNTRY_CD	LOCATION
                    # PARAM_VAL	PARAM_NUM_VAL
                    count += 1
                    tmp_arr = line.rstrip('\n').split(',')
                    if len(tmp_arr) != 8:
                        continue

                    param_cd = tmp_arr[0]
                    model_cd = tmp_arr[1]
                    param_name = tmp_arr[2]
                    external_name = tmp_arr[3]
                    param_type = tmp_arr[4]
                    country_cd = tmp_arr[5]
                    location_cd = tmp_arr[6]
                    param_val_str = tmp_arr[7]
                    if not param_val_str:
                        logger_.info("Detected no value for parameter in record: {}".format(count))
                        continue
                    param_val = None
                    try:
                        param_val = Decimal(param_val_str)
                    except Exception as ex:
                        logger_.error("Error processing line {}. Unable to convert {} to Decimal".format(count,
                                                                                                         param_val_str))

                    sql_exec = sql.format(schema_name, param_cd, model_cd, param_name, external_name,
                                          param_type, param_val, country_cd, location_cd, schema_name, is_active)

                    logger_.info("Executing SQL: {}".format(sql_exec))
                    cursor.execute(sql_exec)
                    loaded += 1
                    if count % 20 == 0:
                        logger_.info("Processed {} model parameter records .. Loaded {} ..".format(count-1, loaded))

        except Exception as ex:
            logger_.error("Unexpected exception while loading data from {}. Msg: {}".format(file_name, ex))
            logger_.info("Failed to process data upload ... ")
            return -1
        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass

        logger_.info("Processed {} data records from file '{}'. Loaded {} successfully".format(count-1,
                                                                                               file_name,
                                                                                               loaded))
        return loaded

    @staticmethod
    def db_update_gas_demand(schema_name, connection_name, is_active=True):

        sql_exec = None
        sql = None
        stasco_env_db_conn = None
        stasco_env_db_cursor = None
        loaded = 0
        cursor = None
        conn = None
        stasco_env_name = os.getenv('STASCO_ENV', None)
        calendar_data_cache = StxDbHelper.cache_stasco_calendar(schema_name, connection_name=connection_name)
        if is_active:
            is_active = 1
        try:
            # stasco environment connection - location of GAS_FUNDAMENTALS Db.
            stasco_env_db_conn = pyodbc_connect(stasco_env_name)
            stasco_env_db_cursor = stasco_env_db_conn.cursor()

            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            sql_exec = StxDbHelper.SQL_DEACTIVATE_STX_GAS_DEMAND_TABLE.format(schema_name,
                                                                              StxDbManager.STX_GAS_DEMAND_TBL_NAME)
            cursor.execute(sql_exec)

            sql = StxDbHelper.STX_GAS_DEMAND_SELECT_SQL

            sql_exec = sql.format('2018-04-01')
            logger_.info("Collecting current demand data from GAS_FUNDAMENTALS, CE schema tables ... ")
            logger_.info("Executing SQL: {}".format(sql_exec))

            stasco_env_db_cursor.execute(sql_exec)
            sql = StxDbHelper.STX_GAS_DEMAND_UPDATE_SQL
            for row in stasco_env_db_cursor:
                demand_type = row[0]
                demand_subtype = row[1]
                asset_id = row[2]
                asset_name = row[3]
                series_id = row[4]
                country_cd = row[5]
                asofdate = row[6]
                demand_amt = row[7]
                location_cd = 'default'
                tmp_arr = asset_name.split(',')
                if len(tmp_arr) == 3:
                    try:
                        cty = tmp_arr[0]
                        if cty != country_cd:
                            raise RuntimeError("Detected asset name containing incorrect country code. Aborting.")
                        demand_type = tmp_arr[1]
                        buf = tmp_arr[2].strip()
                        tmp_arr2 = buf.split(' ')
                        if len(tmp_arr2) == 2:
                            # LDC EA
                            location_cd = tmp_arr2[1]
                    except Exception as pa:
                        logger_.error("Failed parsing demand location code from 'assetName'. Using <default> ")
                        pass

                # asset name example: 'GB, Demand, LDC EA'
                cal_date_info_dict = calendar_data_cache.get(asofdate, None)
                if not cal_date_info_dict:
                    raise RuntimeError("Detected no calendar info for date: {}. Aborting.".format(asofdate))

                sql_exec = sql.format(schema_name, StxDbManager.STX_GAS_DEMAND_TBL_NAME, asofdate,
                                      cal_date_info_dict.get(StxDbManager.CAL_DATE_KEY, 0), demand_type, demand_subtype,
                                      asset_id, series_id, country_cd, location_cd,
                                      demand_amt, schema_name, is_active)
                cursor.execute(sql_exec)
                loaded += 1
                if loaded % 50 == 0:
                    logger_.info("Loaded {} demand records .. ".format(loaded))

            sql_exec = \
                StxDbHelper.SQL_DELETE_INACTIVE_STX_GAS_DEMAND_TABLE.format(schema_name,
                                                                            StxDbManager.STX_GAS_DEMAND_TBL_NAME)
            cursor.execute(sql_exec)

        except Exception as ex:
            logger_.error("Exception loading demand values into: {}. Msg: {}".format(connection_name, ex))
            return -1

        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
            if stasco_env_db_cursor:
                try:
                    stasco_env_db_cursor.close()
                except:
                    pass
            if stasco_env_db_conn:
                try:
                    stasco_env_db_conn.close()
                except:
                    pass
        logger_.info("Loaded {} demand value data records ..".format(loaded))
        return loaded

    @staticmethod
    def db_load_nat_grid_normal_temp(schema_name, file_name, connection_name, is_active=True):

        cursor = None
        sql_exec = None
        sql_insert = StxDbHelper.SQL_INS_NG_STX_LOCATION_TEMPERATURE
        loaded = 0
        processed = 0
        conn = None
        calendar_data_cache = StxDbHelper.cache_stasco_calendar(schema_name, connection_name=connection_name)
        if is_active:
            is_active = 1
        try:
            # Model DB connection            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            sql_exec = \
                StxDbHelper.SQL_DEACT_STX_LOCATION_TEMPERATURE.format(schema_name,
                                                                      StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME)
            cursor.execute(sql_exec)
            with open(file_name, "r") as file_handle:
                for line in file_handle:
                    if processed == 0:
                        processed += 1
                        continue
                    # header: DATE	SC	NO	NW	NE	EM	WM	WN	WS	EA	NT	SE	SO	SW
                    tmp_arr = line.rstrip('\n').split(',')
                    if len(tmp_arr) != 14:
                        processed += 1
                        continue
                    processed += 1
                    asofdate_str = tmp_arr[0]
                    tmp_dict = {}
                    tmp_dict['SC'] = Decimal(tmp_arr[1])
                    tmp_dict['NO'] = Decimal(tmp_arr[2])
                    tmp_dict['NW'] = Decimal(tmp_arr[3])
                    tmp_dict['NE'] = Decimal(tmp_arr[4])
                    tmp_dict['EM'] = Decimal(tmp_arr[5])
                    tmp_dict['WM'] = Decimal(tmp_arr[6])
                    tmp_dict['WN'] = Decimal(tmp_arr[7])
                    tmp_dict['WS'] = Decimal(tmp_arr[8])
                    tmp_dict['EA'] = Decimal(tmp_arr[9])
                    tmp_dict['NT'] = Decimal(tmp_arr[10])
                    tmp_dict['SE'] = Decimal(tmp_arr[11])
                    tmp_dict['SO'] = Decimal(tmp_arr[12])
                    tmp_dict['SW']= Decimal(tmp_arr[13])

                    for (location, temperature_val) in tmp_dict.items():
                        date_key_dict = calendar_data_cache.get(asofdate_str, None)
                        if not date_key_dict:
                            raise RuntimeError("No calendar '{}' in STX calendar cache. Aborting.".format(asofdate_str))
                        sql_exec = sql_insert.format(schema_name, StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME,
                                                     asofdate_str, date_key_dict.get(StxDbManager.CAL_DATE_KEY, 0),
                                                     'UK', location, 'NORMAL', 'NG',
                                                     temperature_val, schema_name, is_active)
                        cursor.execute(sql_exec)
                        loaded += 1
                        if loaded % 2500 == 0:
                            logger_.info("Processed {} NG records .. Loaded {} ..".format(processed, loaded))

            sql_exec = \
                StxDbHelper.SQL_DEL_INACT_STX_LOCAT_TEMPTE.format(schema_name,
                                                                  StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME)
            cursor.execute(sql_exec)

        except Exception as ex:
            logger_.error("Exception loading demand values into: {}. Msg: {}".format(connection_name, ex))
            return -1, -1

        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Processed {} demand value data records ..".format(loaded))
        return processed, loaded

    @staticmethod
    def db_load_weight_factor_data(schema_name, country, file_name, connection_name=None, is_active=True):

        cursor = None
        sql_exec = None
        sql_insert = StxDbHelper.SQL_INS_STX_LOCATION_WEIGHT_FACTOR
        loaded = 0
        processed = 0
        conn = None
        calendar_data_cache = StxDbHelper.cache_stasco_calendar(schema_name, connection_name=connection_name)
        # station_cache[(station_cd, station_name, station_type)] = (external_name, country_cd)
        station_data_cache = StxDbHelper.cache_stasco_station_location(schema_name, country,
                                                                       connection_name=connection_name)
        if is_active:
            is_active = 1
        temp_factor_id = 1 # get from DB
        wind_factor_id = 2 # get from DB
        try:
            # Model DB connection            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
#            sql_exec = \
#                StxDbHelper.SQL_DEACT_STX_LOCATION_WEIGHT_FACTOR.format(schema_name,
#                                                                        StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME)
#            cursor.execute(sql_exec)
            with open(file_name, "r") as file_handle:
                for line in file_handle:
                    country_cd = None
                    location_cd = None
                    business_date_id = 0
                    if processed == 0:
                        processed += 1
                        continue
                    # header: UNIQUE_ID	LOCATION_NAME	GAS_DAY	SOURCE	TEMPERATURE	WIND
                    tmp_arr = line.rstrip('\n').split(',')
                    if len(tmp_arr) != 6:
                        processed += 1
                        continue
                    processed += 1

                    unique_id = tmp_arr[0]
                    location_name = tmp_arr[1].upper()
                    asofdate_str = tmp_arr[2]
                    source_name = tmp_arr[3]
                    tmp_val = None
                    try:
                        temp_val = tmp_arr[4]
                    except Exception as ex:
                        logger_.error("Failed parsing value '{}' while loaded weighted factors.".format(tmp_arr[4]))
                        logger_.error("Skipping processing record {} ...".format(processed))
                        continue
                    wind_val = None
                    try:
                        wind_val = tmp_arr[5]
                    except Exception as ex:
                        logger_.error("Failed parsing value '{}' while loaded weighted factors.".format(tmp_arr[4]))
                        logger_.error("Skipping processing record {} ...".format(processed))
                        continue

                    # get country code and location code
                    for (key, val) in station_data_cache.items():
                        as_of_date = dt.datetime.strptime(asofdate_str, '%Y-%m-%d')
                        date_key_dict = calendar_data_cache.get(as_of_date.date(), None)
                        if not date_key_dict:
                            # found no date in calendar - skip insertion of recs outside of calendar dates
                            break
                        business_date_id = date_key_dict.get(StxDbManager.CAL_DATE_KEY, None)

                        if key[1] == location_name:
                            country_cd = val[1]
                            if not country_cd:
                                country_cd = 'UK'
                            if country != country_cd:
                                break
                            location_cd = key[0]
                            if not location_cd:
                                location_cd = location_name

                            value = None
                            if key[2] == WEATHER_TEMPRE_FACTOR_ID:
                                # weather factor type is 1
                                value = temp_val
                            else:
                                value = wind_val
                            sql_exec = sql_insert.format(schema_name, StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME,
                                                         asofdate_str, business_date_id,
                                                         country_cd, location_cd, key[2], value,
                                                         schema_name, is_active)
                            cursor.execute(sql_exec)
                            loaded += 1
                            if loaded % 5000 == 0:
                                logger_.info("Processed {} NG records .. Loaded {} ..".format(processed, loaded))

            sql_exec = \
                StxDbHelper.SQL_DEL_INACT_STX_LOCAT_WEIGHT_FACTOR.format(schema_name,
                                                                         StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME)
            cursor.execute(sql_exec)

        except Exception as ex:
            logger_.error("Exception loading demand values into: {}. Msg: {}".format(connection_name, ex))
            return -1

        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Processed {} demand value data records ..".format(loaded))
        return processed

    @staticmethod
    def db_update_weight_factor_data(schema_name, country, start_date, connection_name=None, is_active=True):

        sys_trading_conn = None
        sys_trading_cursor = None
        ldz_conn = None
        ldz_cursor = None
        sql_exec = None
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)

        sql_insert = StxDbHelper.SQL_INS_STX_LOCATION_WEIGHT_FACTOR
        loaded = 0
        processed = 0
        calendar_data_cache = StxDbHelper.cache_stasco_calendar(schema_name, connection_name=connection_name)
        # station_cache[(station_cd, station_name, station_type)] = (external_name, country_cd)
        station_data_cache = StxDbHelper.cache_stasco_station_location(schema_name, country,
                                                                       connection_name=connection_name)
        station_name_list = StxDbHelper.get_country_station_name_list(station_data_cache)
        station_name_list_str = "{}".format(",".join(station_name_list).replace(",", "\',\'"))
        if is_active:
            is_active = 1
        temp_factor_id = 1 # get from DB
        wind_factor_id = 2 # get from DB
        try:
            # Model DB connection
            ldz_conn = pyodbc_connect(connection_name=connection_name)
            ldz_cursor = ldz_conn.cursor()
#            SYS_TRAD_WT_FACTOR_LOCATION_COL_NAME = "location_name"
#            SYS_TRAD_WT_FACTOR_GAS_DAY_COL_NAME = "gas_day"
#            SYS_TRAD_WT_FACTOR_SRC_COL_NAME = "Source"
#            SYS_TRAD_WT_FACTOR_TEMPRE_COL_NAME = "Temp"
#            SYS_TRAD_WT_FACTOR_WIND_COL_NAME = "Wind"
            sys_trading_conn = pyodbc_connect(connection_name='SYSTEMATIC TRADING')
            sys_trading_cursor = sys_trading_conn.cursor()
            sql_exec = SYS_TRADING_WEDNESDAY_QUERY.format(station_name_list_str, start_date, start_date,
                                                          station_name_list_str, start_date)
            logger_.info("Executing SQL: {}".format(sql_exec))
            sys_trading_cursor.execute(sql_exec)
            for row in sys_trading_cursor:


                location_name = row[0].upper()
                as_of_date = row[1]
                source_name = row[2]

                temp_val = row[3]
                wind_val = row[4]

                # get country code and location code
                for (key, val) in station_data_cache.items():
                    date_key_dict = calendar_data_cache.get(as_of_date, None)
                    if not date_key_dict:
                        # found no date in calendar - skip insertion of recs outside of calendar dates
                        break
                    business_date_id = date_key_dict.get(StxDbManager.CAL_DATE_KEY, None)
                    if key[1] == location_name:
                        country_cd = val[1]
                        if not country_cd:
                            country_cd = 'UK'
                        if country != country_cd:
                            break
                        location_cd = key[0]
                        if not location_cd:
                            location_cd = location_name
                        value = None
                        if key[2] == WEATHER_TEMPRE_FACTOR_ID:
                            # weather factor type is 1
                            value = temp_val
                        else:
                            value = wind_val
                        if value is None:
                            value = 'NULL'
                        sql_exec = sql_insert.format(schema_name, StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME,
                                                     as_of_date.strftime('%Y-%m-%d'), business_date_id,
                                                     country_cd, location_cd, key[2], value,
                                                     schema_name, is_active)
#                        logger_.info("Executing SQL: {}".format(sql_exec))
                        ldz_cursor.execute(sql_exec)
                        loaded += 1
                        if loaded % 5000 == 0:
                                logger_.info("Processed {} NG records .. Loaded {} ..".format(processed, loaded))
            processed += 1
            sql_exec = \
                StxDbHelper.SQL_DEL_INACT_STX_LOCAT_WEIGHT_FACTOR.format(schema_name,
                                                                         StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME)
            ldz_cursor.execute(sql_exec)

        except Exception as ex:
            logger_.error("Exception loading demand values into: {}. Msg: {}".format(connection_name, ex))
            return -1

        finally:
            if ldz_cursor:
                try:
                    ldz_cursor.close()
                except:
                    pass
            if ldz_conn:
                try:
                    ldz_conn.close()
                except:
                    pass
            if sys_trading_cursor:
                try:
                    sys_trading_cursor.close()
                except:
                    pass
            if sys_trading_conn:
                try:
                    sys_trading_conn.close()
                except:
                    pass
        logger_.info("Processed {} demand value data records ..".format(loaded))
        return processed


def core__(loader, table_to_load_list, country, start_date, asof_date, home_dir, connection_name, schema_name='LDZ',
           is_active=True):

    for table in table_to_load_list:
        csv_dir = os.path.join(home_dir, "data" + os.path.sep + "db" + os.path.sep + "csv")
        if table == StxDbManager.STX_CALENDAR_TBL_NAME:
            # ------------- LOAD STX_CALENDAR ---------------
            filename = STX_TABLE_TO_FILE_MAP.get(table, None)
            if not filename:
                continue
            filename = os.path.join(csv_dir, filename)
            loader.db_load_calendar(schema_name, filename, connection_name=connection_name)
        elif table == StxDbManager.STX_MODEL_PARAMETER_TBL_NAME:
            # ------------- LOAD STX_MODEL_PARAMETER --------
            filename = STX_TABLE_TO_FILE_MAP.get(table, None)
            if not filename:
                continue
            filename = os.path.join(csv_dir, filename)
            MarketDataLoader.db_load_model_param(schema_name, filename, connection_name,
                                                 is_active=is_active)
        elif table == StxDbManager.STX_GAS_DEMAND_TBL_NAME:
            # ------------- UPDATE STX_MODEL_PARAMETER --------
            # update to table using Commodity Essentials CE schema in GAS_FUNDAMENTALS Db.
            MarketDataLoader.db_update_gas_demand(schema_name, connection_name, is_active=is_active)
        elif table == StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME:
            MarketDataLoader.db_update_weight_factor_data(schema_name, country, start_date,
                                                          connection_name=connection_name)

            # upload sample input of weighted temperature and wind factors for locations
#            filename = STX_TABLE_TO_FILE_MAP.get(table, None)
#            if not filename:
#                continue
#            filename = os.path.join(csv_dir, filename)
#            MarketDataLoader.db_load_weight_factor_data(schema_name, country, filename, connection_name,
#                                                        is_active=is_active)

        elif table == StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME:
            # -------- UPDATE STX_LOCATION_TEMPERATURE ------
            # upload table with national grid temperature values
            filename = StxDbHelper.STX_TABLE_TO_FILE_MAP.get(table, None)
            if not filename:
                continue
            filename = os.path.join(csv_dir, filename)
            MarketDataLoader.db_load_nat_grid_normal_temp(schema_name, filename, connection_name,
                                                          is_active=is_active)
        return 0


def main(argv):

    table = None
    asof = None
    country = None
    start_date = None
    try:
        opts, args = getopt.getopt(argv, "ht:a:s:c:", ["table=", "asof=", "start_date=", "country="])
    except getopt.GetoptError as er:
        print(er)
        print("{} -t <table> -a <asof>".format(__name__))
        return -2

    for opt, arg in opts:
        if opt == '-h':
            print("{}.py -t <table> -a <asof> -c <country>".format(__name__))
            return 1
        if opt in ("-t", "--table"):
            table = arg
        elif opt in ("-a", "--asof"):
            asof = arg
        elif opt in ("-s", "--start_date"):
            start_date = arg
        elif opt in ("-c", "--country"):
            country = arg

    print("Tables to load: {}".format(table))
    print("Run asof      : {}".format(asof))

    table_to_load_list = None
    if table:
        table_to_load_list = table.replace(' ', '').split(',')

    run_as_of_dt = None
    if asof:
        run_as_of_dt = dt.datetime.strptime(asof, '%Y-%m-%d')
    if not table:
        logger_.info("No tables to load data specified. Exiting ..")
        return 0
    if not country:
        country = "UK"
    if not start_date:
        start_date = StxDbManager.DEFAULT_DATA_START_DATE

    connection_name = os.getenv('STASCO_DB_NAME', None)
    if not connection_name:
        logger_.error("STASCO database name undefined. Define 'STASCO_DB_NAME env. variable.")
        return -1
    loader = MarketDataLoader()
    logger_.info("Starting load for table(s): {} .. ".format(table))
    home_dir = os.getenv('STASCO_HOME', None)
    if not home_dir:
        logger_.error("STASCO HOME directory not set. Define 'STASCO_HOME env. variable.")
        return -1

    return core__(loader, table_to_load_list, country, start_date, run_as_of_dt.date(), home_dir, connection_name)


if __name__ == '__main__':

    ret_cd = main(sys.argv[1:])
    sys.exit(ret_cd)

