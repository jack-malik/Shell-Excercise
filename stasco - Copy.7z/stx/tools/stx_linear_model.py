import os
import getopt
import logging
import datetime as dt
import sys
from decimal import Decimal, getcontext

import numpy as np
from sklearn.linear_model import LinearRegression

from stx.util.connections import pyodbc_connect
from stx.util.stx_db_manager import StxDbManager
from stx.util.stx_db_helper import StxDbHelper
from stx.util.stx_model_helper import StxModelHelper

logger_ = logging.getLogger(__name__)
logger_.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('[%(asctime)s]-[%(name)s]-[%(levelname)s]: %(message)s')
handler.setFormatter(formatter)
logger_.addHandler(handler)

class StxLinearModel(object):

    MODEL_NAME = 'NG'

    def __init__(self, user_name=None, start_date=None, as_of_date=None, country=None, connection_name=None):

        # model executor/owner
        self.schema_name = StxDbManager.DEFAULT_SCHEMA_NAME
        if user_name:
            # model owner is the schema name of used to commit model input/ouput data
            self.schema_name = user_name

        # execution as of date
        self.as_of_date = dt.datetime.now()
        if as_of_date:
            self.as_of_date = as_of_date

        # execution as of date
        self.start_date = StxDbManager.DEFAULT_DATA_START_DATE
        if start_date:
            self.start_date = start_date

        self.country = country

        # connection to DB
        self.connection_name = os.getenv('STASCO_DB_NAME', None)
        if connection_name:
            self.connection_name = connection_name
        if not self.connection_name:
            logger_.error("STASCO database name undefined. Define 'STASCO_DB_NAME env. variable.")
            raise RuntimeError("Detected no DB connection information. Define 'STASCO_DB_NAME' env. variable")

        self.calendar_data_cache = None
        self.model_input_cache = None
        self.station_locat_cache = None

    def initialize(self, user_name=None, start_date=None, as_of_date=None, connection_name=None):

        if user_name:
            self.schema_name = user_name
        if start_date:
            self.start_date = start_date
        if as_of_date:
            self.as_of_date = as_of_date
        if connection_name:
            self.connection_name = connection_name

        # StxDbManager.STX_LOCAT_WEIGHT_FACTOR_TBL_NAME:
        dlw_factor_cache = StxDbHelper.cache_date_location_weight_factor(self.schema_name,
                                                                         self.start_date,
                                                                         self.as_of_date,
                                                                         connection_name=self.connection_name)
        # StxDbManager.STX_LOCAT_TEMPTE_TBL_NAME:
        norm_tempre_cache = StxDbHelper.cache_country_location_norm_tempre(self.schema_name,
                                                                           self.start_date,
                                                                           self.as_of_date,
                                                                           connection_name=self.connection_name)
        # StxDbManager.STX_MODEL_PARAMETER_TBL_NAME - country-location-model_param-val
        model_param_cache = StxDbHelper.cache_stasco_model_parameter(self.schema_name,
                                                                     self.start_date,
                                                                     self.as_of_date,
                                                                     connection_name=self.connection_name)
        # StxDbManager.STX_CALENDAR_TBL_NAME:
        self.calendar_data_cache = StxDbHelper.cache_stasco_calendar(self.schema_name,
                                                                     start_date=self.start_date,
                                                                     connection_name=self.connection_name)
        # StxDbManager.STX_WEATHER_STATION_TBL_NAME:
        self.station_locat_cache = StxDbHelper.cache_stasco_station_location(self.schema_name,
                                                                             self.country,
                                                                             connection_name=self.connection_name)
        # StxDbHelper.DATE_MODEL_LOCAT_PARAM_CACHE_NAME:
        from_db_dmpl_cache = StxDbHelper.cache_date_model_param_location(self.schema_name,
                                                                         self.start_date,
                                                                         self.as_of_date,
                                                                         connection_name=self.connection_name)
        self.model_input_cache = StxModelHelper.prepare_model_input_cache__(dlw_factor_cache, norm_tempre_cache,
                                                                            model_param_cache,
                                                                            from_db_dmpl_cache)
        return True

    def save_model_input__(self, connection_name=None):

        loaded = 0
        if not connection_name:
            connection_name = os.getenv('STASCO_DB_NAME', None)
        if not connection_name:
            logger_.error("STASCO database name undefined. Define 'STASCO_DB_NAME env. variable.")
            return -1

        calendar_date_str = self.as_of_date.strftime('%Y-%m-%d')
        tmp_date_dict = self.calendar_data_cache.get(self.as_of_date, None)
        business_date_key = tmp_date_dict[StxDbManager.CAL_DATE_KEY]
        sql_insert = StxDbHelper.SQL_INS_NG_MODEL_INPUT
        model_input_cache = self.model_input_cache
        cursor = None
        conn = None
        try:
            next_model_exec_run_num = \
                StxDbHelper.get_next_model_run_seq_number(connection_name=connection_name)
            # Model DB connection
            conn = pyodbc_connect(connection_name=connection_name)
            cursor = conn.cursor()
            for (key_tpl, input_dict) in model_input_cache.items():
                calendar_date = key_tpl[0]
                calendar_date_str = calendar_date.strftime('%Y-%m-%d')
                country_cd = key_tpl[1]
                location_cd = key_tpl[2]
                param_etw = input_dict[StxModelHelper.PARAM_ETW]
                param_i1 = input_dict[StxModelHelper.PARAM_I1]
                param_i2 = input_dict[StxModelHelper.PARAM_I2]
                param_i3 = input_dict[StxModelHelper.PARAM_I3]
                param_v0 = input_dict[StxModelHelper.PARAM_V0]
                param_v1 = input_dict[StxModelHelper.PARAM_V1]
                param_v2 = input_dict[StxModelHelper.PARAM_V2]
                param_q = input_dict[StxModelHelper.PARAM_Q]
                param_w0 = input_dict[StxModelHelper.PARAM_W0]
                param_t0 = input_dict[StxModelHelper.PARAM_T0]
                param_s0 = input_dict[StxModelHelper.PARAM_S0]
                calc_actual_weighted_tempre = input_dict[StxModelHelper.AT_WEIGHT_TEMP_KEY]
                calc_efective_tempre = input_dict[StxModelHelper.ET_EFFECT_TEMP_KEY]
                calc_weighted_wind_speed = input_dict[StxModelHelper.WT_WEIGHT_WIND_KEY]
                calc_season_norm_tempre = input_dict[StxModelHelper.ST_NORMAL_TEMP_KEY]
                calc_max_t0_minus_at = input_dict[StxModelHelper.MAX_T0_MINUS_AT_TERM_KEY]
                calc_max_wt_minus_w0 = input_dict[StxModelHelper.MAX_WT_MINUS_W0_TERM_KEY]
                calc_cw_term = input_dict[StxModelHelper.CWT_TERM_KEY]

                calc_cwv_cold = input_dict[StxModelHelper.CWV_COLD_KEY]
                if not calc_cwv_cold:
                    calc_cwv_cold = 'NULL'
                calc_cwv_normal = input_dict[StxModelHelper.CWV_NORMAL_KEY]
                if not calc_cwv_normal:
                    calc_cwv_normal = 'NULL'
                calc_cwv_transition = input_dict[StxModelHelper.CWV_TRANSITION_KEY]
                if not calc_cwv_transition:
                    calc_cwv_transition = 'NULL'
                calc_cwv_summer = input_dict[StxModelHelper.CWV_SUMMER_KEY]
                if not calc_cwv_summer:
                    calc_cwv_summer = 'NULL'
                sql_exec = sql_insert.format(self.schema_name,
                                             StxDbManager.STX_MODEL_INPUT_CALC_TBL_NAME,
                                             calendar_date_str,
                                             business_date_key,
                                             next_model_exec_run_num,
                                             StxLinearModel.MODEL_NAME,
                                             country_cd,
                                             location_cd,
                                             param_etw,
                                             param_i1,
                                             param_i2,
                                             param_i3,
                                             param_v0,
                                             param_v1,
                                             param_v2,
                                             param_q,
                                             param_w0,
                                             param_t0,
                                             param_s0,
                                             calc_actual_weighted_tempre,
                                             calc_efective_tempre,
                                             calc_weighted_wind_speed,
                                             calc_season_norm_tempre,
                                             calc_max_t0_minus_at,
                                             calc_max_wt_minus_w0,
                                             calc_cw_term,

                                             calc_cwv_cold,
                                             calc_cwv_normal,
                                             calc_cwv_transition,
                                             calc_cwv_summer,

                                             self.schema_name,
                                             1)
                cursor.execute(sql_exec)
                loaded += 1
                if loaded % 500 == 0:
                    logger_.info("Loaded {} model input records ..".format(loaded))

        except Exception as ex:
            logger_.error("Exception loading demand values into: {}. Msg: {}".format(connection_name, ex))
            return -1

        finally:
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if conn:
                try:
                    conn.close()
                except:
                    pass
        logger_.info("Processed {} demand value data records ..".format(loaded))
        return loaded

    def build_model_input_timeseries__(self):

        logger_.info("Executing linear model for user schema: '{}' - as of date: '{} ..".format(self.schema_name,
                                                                                                self.as_of_date))
        date_to_cwv_map = {}
        for (key_tpl, input_dict) in self.model_input_cache.items():
            calendar_date = key_tpl[0]
            cal_date_info_dict = self.calendar_data_cache[calendar_date]
#            if cal_date_info_dict[StxDbHelper.CAL_DAY_NUM_OF_WEEK_COL_NAME]  \
#                    not in StxDbHelper.CAL_MON_THU_WEEK_DAY_NUM_LIST:
#                continue
            calc_cwv_val = input_dict.get(StxModelHelper.CWV_NORMAL_KEY, None)
            if not calc_cwv_val:
                calc_cwv_val = input_dict.get(StxModelHelper.CWV_COLD_KEY, None)
            if not calc_cwv_val:
                calc_cwv_val = input_dict.get(StxModelHelper.CWV_TRANSITION_KEY, None)
            if not calc_cwv_val:
                calc_cwv_val = input_dict[StxModelHelper.CWV_SUMMER_KEY]
            location_cd = key_tpl[2]
            date_to_cwv_map[(calendar_date, location_cd)] = calc_cwv_val
            tmp_ = date_to_cwv_map.get((calendar_date, location_cd), None)
            if location_cd == 'NE':
                logger_.info("{} for {}.{} ..".format(tmp_, calendar_date, location_cd))

        return date_to_cwv_map

    def build_gas_demand_timeseries__(self):

        date_to_gas_demand_cache = StxDbHelper.cache_gas_demand(self.schema_name,
                                                                self.country,
                                                                start_date=self.start_date,
                                                                as_of_date=self.as_of_date,
                                                                connection_name=self.connection_name)
        return date_to_gas_demand_cache

    def execute(self):

        date_locat_to_cwv_map = self.build_model_input_timeseries__()
        date_station_to_gas_demand_map = self.build_gas_demand_timeseries__()
        locat_to_tm_series_map = {}
        count = 0
        for (date_location_tpl, demand_amt) in date_station_to_gas_demand_map.items():
            tmp_date = date_location_tpl[0]
            tmp_locat = date_location_tpl[1]
            locat_to_tm_series_map_entry = locat_to_tm_series_map.get(tmp_locat, None)
            if not locat_to_tm_series_map_entry:
                locat_to_tm_series_map_entry = []
            tmp_cwv = date_locat_to_cwv_map.get((tmp_date, tmp_locat), None)
            if not tmp_cwv:
                logger_.info("No CWV entry for: '{}.{}".format(tmp_date, tmp_locat))
                continue
            locat_to_tm_series_map_entry.append((tmp_date, demand_amt, tmp_cwv))
            locat_to_tm_series_map[tmp_locat] = locat_to_tm_series_map_entry
            count += 1
        logger_.info("Created timeseries of date-cwv-demand for {} locations ..".format(len(locat_to_tm_series_map)))
        for (key, value) in locat_to_tm_series_map.items():
            if key == 'EA':
                logger_.info("{}".format(value))
        return locat_to_tm_series_map

    def terminate(self):
        pass


def core__(model, user_name='LDZ', start_date=None, as_of_date=None, connection_name=None):

    try:
        # prepare model - cache data - build dmlp cache of paramet
        model.initialize(user_name=user_name, start_date=start_date, as_of_date=as_of_date,
                         connection_name=connection_name)
        # ttl_input_records = model.save_model_input__(connection_name=connection_name)
        logger_.info("Saved total of {} model input records to DB.".format(len(model.model_input_cache)))

    except Exception as ex:
        logger_.error("Unexpected exception while preparing LM for execution. {}".format(ex))
        return -1

    try:
        model.execute()
    except Exception as ex:
        logger_.error("Unexpected exception while executing LM for execution. {}".format(ex))
        return -1

    try:
        model.terminate()
    except Exception as ex:
        logger_.error("Unexpected exception while termination LM execution. {}".format(ex))
        return -1

    return 0

def main(argv):

    user = None
    as_of_date = None
    start_date = None
    country_list = None
    try:
        opts, args = getopt.getopt(argv, "hu:s:c:", ["user=", "as_of_date=", "start_date=", "country="])
    except getopt.GetoptError as er:

        logger_.error("Unexpected exception parsing arguments. {}".format(er))
        logger_.info("{} -u <user DB schema name> -a <running as-of date>".format(__name__))
        return -2

    for opt, arg in opts:
        if opt == '-h':
            logger_.info("{} -u <user DB schema name> -a <running as-of date>".format(__name__))
            return 0
        if opt in ("-u", "--user"):
            user = arg
        elif opt in ("-a", "--as_of_date"):
            as_of_date = arg
        elif opt in ("-s", "--start_date"):
            start_date = arg
        elif opt in ("-c", "--country"):
            country_list = arg.strip().split(',')

    run_as_of_dt = dt.datetime.now()
    if as_of_date:
        run_as_of_dt = dt.datetime.strptime(as_of_date, '%Y-%m-%d')
    if start_date:
        start_date = dt.datetime.strptime(start_date, '%Y-%m-%d')

    logger_.info("Starting execution of linear model LM as of: {} .. ".format(run_as_of_dt))
    home_dir = os.getenv('STASCO_HOME', None)
    if not home_dir:
        logger_.error("STASCO HOME directory not set. Define 'STASCO_HOME env. variable before executing ...")
        return -1

    for country in country_list:
        try:
            model = StxLinearModel(user, as_of_date=run_as_of_dt.date(), start_date=start_date, country=country)
        except Exception as ex:
            logger_.error("Failed instantiating LM for date: {} - country: {} ..".format(run_as_of_dt, country))
        try:
            core__(model, user_name=None, start_date=start_date, as_of_date=run_as_of_dt.date())
        except Exception as ex:
            logger_.error("Failed executing LM for date: {} - country: {} ..".format(run_as_of_dt, country))


if __name__ == '__main__':

    ret_cd = main(sys.argv[1:])
    sys.exit(ret_cd)

